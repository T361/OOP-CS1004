#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <vector>
// Taimoor Shaukat , 24i-3015 ,BSE-B
using namespace std;
class account{// account class for the library fine and other specfics
    protected:
    int borrowedbooks;
    int lostbooks;
    int reservedbooks;
    float fineamount;
    public:
    account(int r=0,int e=0,int y=0,float k=0)
    {
        borrowedbooks = r;
        lostbooks = e;
        reservedbooks = y;
        fineamount = k;
    }
    void calculatefine()
    {
        cout<<"Fine is "<<lostbooks*fineamount<<endl;
    }
    void setborrowed(int s)
    {
        borrowedbooks = s;
    }
    void setlost(int r)
    {
        lostbooks = r;
    }
    void setreserved(int k)
    {
        reservedbooks = k;
    }
    void setfine(float e)
    {
        fineamount = e;
    }

    int getborrowed()
    {
       return borrowedbooks;
    }
    int getlost()
    {
        return lostbooks;
    }
    int getreserved()
    {
        return reservedbooks;
    }
    float getfine(float e)
    {
        return fineamount;
    }
};
class page{// page class for the book
    private:
    string text;
    int pageno;
    public:
    page(string t="",int n=-1)
    {
        text = t;
        pageno = n;
    }
    void settext(string t)
    {
        text = t;
    }
    void setpageno(int i)
    {
        pageno = i;
    }
    string gettext()
    {
        return text;
    }
    int getpageno()
    {
        return pageno;
    }
};
class book{//class for each books title author and specfications
    private:
    string title;
    string author;
    string isbn;
    page *p;
    bool status=false;
    int dueday=1 + (rand() %(7-(1)+1));
    public:
    book(string t="",string a="",string i="")
    {
        title = t;
        author = a;
        isbn = i;
    }
    void settitle(string t)
    {
        title = t;
    }
    void setauthor(string a)
    {
        author = a;
    }
    void setisbn(string i)
    {
        isbn = i;
    }
    void setdue(int m)
    {
        dueday = m;
    }
    string gettitle()
    {
        return title;
    }
    string getauthor()
    {
        return author;
    }
    string getisbn()
    {
        return isbn;
    }
    void showduedate()
    {
         cout<<" DUE "<<dueday<<endl;
    }
    bool reservestatus()
    {
        return status;
    }
    void bookrequest(bool s)
    {
        status = true;
    }
    void renewinfo()
    {
        status = false;
        dueday = 1 + (rand() %(7-(1)+1));
    }
};
class lms{// library management system for other users to login 
    private:
    int usertype;
    string username;
    string password;
    public:
    lms(int i=-1,string u="",string p="")
    {
        usertype = i;
        username = u;
        password = p;
    }
    int gettype()
    {
        return usertype;
    }
    string getname()
    {
        return username;
    }
    string getpass()
    {
        return password;
    }
    void settype(int i)
    {
        usertype = i;
    }
    void setname(string n)
    {
        username = n;
    }
    void setpass(string p)
    {
        password = p;
    } 
    void reg(int id,string n, string p)
    {
        usertype = id;
        username = n;
        password = p;
        cout<<"Your user type is "<<usertype<<endl;
    }
    bool login(int id,string n,string p)
    {
        if(id==usertype&&n==username&&password==p)
        {
            return true;
        }
        else
        {   
            return false;
        }
    }
    void logout()
    {
        cout<<"Youve logged out "<<endl;
    }
};
class librarian// librarian class for its attributes and for librarian to login
{
    private:
    string name;
    int id;
    string password;
    public:
    librarian(string n="",int i=-1,string p="")
    {
        name = n;
        id = i;
        password = p;
    }
    string getname()
    {
        return name;
    }
    int getid()
    {
        return id;
    }
    string getpass()
    {
        return password;
    }
    void setname(string n)
    {
        name=n;
    }
    void setid(int i)
    {
        id = i;
    }
    void setpass(string p)
    {
        password = p;
    }
    bool verify_librarian(string n, int i,string p)
    {
        if(n==name&&i==id&&p==password)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool search_book(book *list,string in,int size)
    {
        for(int i=0;i<size;i++)
        {
            if(list[i].getisbn()==in)
            {
                return true;
            }
        }
        return false;
    }
};
class library{// class for library for the amount of books and issuing and returning
    private:
    int size;
    vector<book>list;
    public:
    library(int s)
    {
        size = s;
    }
    void setsize(int s)
    {
        size =s;
    }
    int getsize()
    {
        return size;
    }
    void add(book &b)
    {
      list.push_back(b);
      size++;
    }
    void del()
    {
        list.pop_back();
        size--;
    }
    void update()
    {
        int found=-1;
        string search;
        cout<<"which would you like to update enter isbn"<<endl;
        cin>>search;
        for(int i=0;i<list.size();i++)
        {
            if(search==list[i].getisbn())
            {
                found = i;
            }
        }
        string n;
        string i;
        string t;
        int d;
        if(found!=-1)
        {
            cout<<"what would u like to change the isbn title author and days till due "<<endl;
            cin>>n;
            cin>>i;
            cin>>t;
            deeznuts:
            cin>>d;
            if(d<=0)
            {
                cout<<"invalid"<<endl;
                goto deeznuts;
            }
            list[found].setisbn(n);
            list[found].settitle(i);
            list[found].setauthor(t);
            list[found].setdue(d);
        }
        else
        {
            cout<<" book not found "<<endl;
        }
    }
    void display(string search)
    {
        int found=-1;
        for(int i=0;i<list.size();i++)
        {
            if(search==list[i].getisbn())
            {
                found = i;
            }
        }
        if(found>-1)
        {
            cout<<list[found].getauthor()<<endl;
            cout<<list[found].gettitle()<<endl;
            cout<<"isbn"<<endl;
            cout<<list[found].getisbn()<<endl;
            cout<<"due days "<<endl;
            list[found].showduedate();
        }
        else
        {
            cout<<"book not found "<<endl;
        }
    }

    book& search()
    {
        int found=-1;
        string search;
        cout<<"which would you like to search enter isbn"<<endl;
        cin>>search;
        for(int i=0;i<list.size();i++)
        {
            if(search==list[i].getisbn())
            {
                found = i;
            }
        }
        if(found>-1)
        {
            return list[found];
        }
        else
        {
            cout<<"book not found "<<endl;
        }
    }
};
class user: public account// user class inherits account as an account has a user , user includes details for libraries users
{
    protected:
    string name;
    int id;
    public:
    user(string n="",int i=-1,int r=0,int e=0,int y=0,float k=0) : account(r,e,y,k)
    {
        name = n;
        id = i;
    }
    string getname()
    {
        return name;
    }
    int getid()
    {
        return id;
    }
    void setname(string d)
    {
        name = d;
    }
    void setid(int i)
    {
        id = i;
    }
    bool verify(string n,int g)
    {
        if(name==n&&id==g)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    void checkaccount()
    {
        cout<<getborrowed()<<endl;
        cout<<getlost()<<endl;
        cout<<getreserved()<<endl;
        calculatefine();
    }
    void getbookinfo(book &b)
    {
        cout<<b.getauthor()<<endl;
        cout<<b.gettitle()<<endl;
        cout<<b.getisbn()<<endl;
    }
};
class staff : public user// staff is a user also hence it inherits from user aswell , staff has all their details
{
    private:
    string dept;
    string designation;
    int dueweeks = 16;
    public:
    staff(string d="" , string de="",string n="",int i=-1):user(n,i)
    {
        dept = d;
        designation = de;
    }
    string getdept()
    {
        return dept;
    }
    string getdes()
    {
        return designation;
    }
    void setdept(string r)
    {
        dept = r;
    }
    void setdes(string f)
    {
        designation = f;
    }
    void due()
    {
        cout<<"dueweeks "<<dueweeks<<endl;
    }

};
class student :public user// student is also a user hence it herits from it aswell , student includes all its details
{
    private:
    string batch;
    string designation;
    int dueday=14;
    public:
    student(string d="" , string de="",string n="",int i=-1):user(n,i)
    {
        batch = d;
        designation = de;
    }
    string getbatch()
    {
        return batch;
    }
    string getdes()
    {
        return designation;
    }
    void setbatch(string r)
    { 
        batch= r;
    }
    void setdes(string f)
    {
        designation = f;
    }
    void due()
    {
        cout<<"duedays "<<dueday<<endl;
    }
};
int main()
{
    // test cases 
    lms admin;
    librarian lib1("librarian",1,"password");
    if(lib1.verify_librarian("librarian",1,"password"))
    {
        cout<<"libararian logged in "<<endl;
    }
    else
    {
        cout<<"librarian not logged in"<<endl;
    }
    library hubeg(10);
    book book1("Harry Potter", "J.K. Rowling", "ISBN1");
    book book2("The Hobbit", "J.R.R. Tolkien", "ISBN2");
    book book3("1984", "George Orwell", "ISBN3");
    book book4("To Kill a Mockingbird", "Harper Lee", "ISBN4");
    book book5("Pride and Prejudice", "Jane Austen", "ISBN5");
    book book6("The Great Gatsby", "F. Scott Fitzgerald", "ISBN6");
    book book7("The Catcher in the Rye", "J.D. Salinger", "ISBN7");
    book book8("Moby-Dick", "Herman Melville", "ISBN8");
    book book9("War and Peace", "Leo Tolstoy", "ISBN9");
    book book10("The Lord of the Rings", "J.R.R. Tolkien", "ISBN10");
    hubeg.add(book1);
    hubeg.add(book2);
    hubeg.add(book3);
    hubeg.add(book4);
    hubeg.add(book5);
    hubeg.add(book6);
    hubeg.add(book7);
    hubeg.add(book8);
    hubeg.add(book9);
    hubeg.add(book10);
    cout<<"books issued by student 1"<<endl;
    hubeg.display("ISBN1");
    hubeg.display("ISBN2");
    hubeg.del();
    hubeg.del();
    hubeg.del();
    hubeg.del();
    hubeg.del();
    hubeg.del();
    hubeg.del();
    student stu1("24","CS","SHEIKH",1);
     stu1.setfine(1989.44);    
     stu1.setborrowed(2);
    student stu2("24","CS","DANISH",2);
    stu2.setfine(1989.44);    
    stu2.setborrowed(3);
    staff sta1("CS","MANAGER","KHAN",3);
    sta1.setfine(1989.44);
    sta1.setborrowed(2);
    stu1.due();
    stu2.due();
    sta1.due();
    hubeg.add(book3);
    hubeg.add(book4);
    hubeg.add(book5);
    stu2.setborrowed(0);
    stu2.setlost(1);
    cout<<"FINE FOR STUDENT 2"<<endl;
    stu2.calculatefine();
}