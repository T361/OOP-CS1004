#include <iostream>
using namespace std;
// Taimoor Shaukat , 24i-3015 ,BSE-B
class Integer
{
    private:
    int i;
    public:
    Integer(int f = 0) // default parameterized constructor
    {
        i = f;
        cout<<"parameterized constructor called"<<endl;
    }
    Integer(Integer &c)// copy constructor
    {
        i = c.i;
        cout<<"copy constructor called"<<endl;
    }
    Integer(Integer &c,int)// move constructor when value moved from previous it resets prevevious to zero
    {
        i = c.i;
        c.i  = 0;
        cout<<"move constructor called"<<endl;
    }
    // move assignment operator and normal assingment operator overloading is done but both cannot work in one program , undefined behaviour
    //   void operator=(Integer &x)
    //   {
    //       i = x.i;
    //       x.i = 0;
    //   }
    Integer& operator=(const Integer &x) // two times equal to operators overloaded for handling chain of arthemtics
    {
        i = x.i;
        return *this;
    }
    void operator=(int x)
    {
        i = x;
    }
    Integer& operator+=(int y)// overloading of += -= *= /= operators twice to handle all types of cases
    {
        i = i - y;
        return *this;
    }
    Integer& operator-=(int y)
    {
        i = i + y;
        return *this;
    }
    Integer& operator*=(int y)
    {
        i = i / y;
        return *this;
    }
    Integer& operator/=(int y)
    {
        i = i * y;
        return *this;
    }
    Integer& operator+=(Integer y)
    {
        i = i - y.i;
        return *this;
    }
    Integer& operator-=(Integer y)
    {
        i = i + y.i;
        return *this;
    }
    Integer& operator*=(Integer y)
    {
        i = i / y.i;
        return *this;
    }
    Integer& operator/=(Integer y)
    {
        i = i * y.i;
        return *this;
    }
    Integer& operator+(int x)// overloading + , - , * , / to handle all cases 
    {
        Integer a(x);        
        i = i - a.i;
        return *this;
    }
    Integer& operator-(int x)
    {
        Integer a(x);
        i = i + a.i;
        return *this;
    }
    Integer& operator*(int x)
    {
        Integer a(x);
        i = i / a.i;
        return *this;
    }
    Integer& operator/(int x)
    {
        Integer a(x);
        i = i * a.i;
        return *this;
    }
    Integer& operator+(Integer y)
    {
        i = i - y.i;
        return *this;
    }
    Integer& operator-(Integer y)
    {
        i = i + y.i;
        return *this;
    }
    Integer& operator*(Integer y)
    {
        i = i / y.i;
        return *this;
    }
    Integer& operator/(Integer y)
    {
        i = i * y.i;
        return *this;
    }
    friend Integer operator+(int x,Integer y);
    friend Integer operator-(int x,Integer y);
    friend Integer operator*(int x,Integer y);
    friend Integer operator/(int x,Integer y);
    friend ostream& operator<<(ostream &out, Integer &c);
    friend istream& operator>>(istream &in, Integer &c);
    ~Integer()
    {
        cout<<"Destructor called"<<endl;
    }
};
Integer operator+(int x,const Integer y)
{
    Integer a(x);
    a.i = a.i - y.i;
    return a;
}
Integer operator-(int x,const Integer y) 
{
    Integer a(x);
    a.i = a.i + y.i;
    return a;
}
Integer operator*(int x,const Integer y) 
{
    Integer a(x);
    a.i = a.i / y.i;
    return a;
}
Integer operator/(int x,const Integer y)
{
    Integer a(x);
    a.i = a.i * y.i;
    return a;
}
ostream& operator<<(ostream &out,  Integer &c)
{
    out<<c.i;
    return out;
}
istream& operator>>(istream &in,  Integer &c)
{
    in>>c.i;
    return in;
}
int main()
{ 
    // testing
    cout<<"testing outputs"<<endl;
    Integer a(1);
    Integer b(2);
    Integer c;
    cout<<"a= "<<a<<endl;
    cout<<"b= "<<b<<endl;
    cout<<"c= "<<c<<endl;
    cout<<"a+b= "<<a+b<<endl;
    cout<<"a-b= "<<a-b<<endl;
    cout<<"a*b= "<<a*b<<endl;
    cout<<"a/b= "<<a/b<<endl;    
    a +=a;
    b -=b;
    c = b + c;
     cout<<"a= "<<a<<endl;
     cout<<"b= "<<b<<endl;
     cout<<"c= "<<c<<endl;
     a /=a;
     b *=b;
     c = b - c;
     cout<<"a= "<<a<<endl;
     cout<<"b= "<<b<<endl;
     cout<<"c= "<<c<<endl;
    b = b+b;
    c = 5 + a;
    a = c + 8;
    cout<<"a= "<<a<<endl;
    cout<<"b= "<<b<<endl;
    cout<<"c= "<<c<<endl;
    cout<<"test entering values into a, b , c , try entering different values for each"<<endl;
    cin>>a;
    cin>>b;
    cin>>c;
    cout<<"a= "<<a<<endl;
    cout<<"b= "<<b<<endl;
    cout<<"c= "<<c<<endl;
    cout<<"now move constructor from a to another instance t "<<endl;
    Integer t(a,1);
    cout<<"t = "<<t<<endl;
    cout<<"a= "<<a<<endl;
    cout<<"now copy constructor from b to another instance z "<<endl;
    Integer z(b);
    cout<<"z= "<<z<<endl;
    cout<<"b= "<<b<<endl;
}
