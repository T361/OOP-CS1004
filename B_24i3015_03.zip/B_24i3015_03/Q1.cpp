#include <iostream>
#include <string>
#include <windows.h>
#include <vector>
using namespace std;
// Taimoor Shaukat , 24i-3015 ,BSE-B
class histogram{// histogram class 
    private:
    vector <double> bins;
    vector <double> data;
    public:
    histogram(vector <double> b)// histogram basic constructor
    {
        bins = b;
    }
    histogram(histogram &d)// histogram copy constructor
    {
        bins = d.bins;
        data = d.data;
    }
    histogram(histogram &d,int)// histogram move constructor
    {
        bins = d.bins;
        data = d.data;
        for(int i=0;i<d.bins.size();i++)
        {
            d.bins.pop_back();
        }
        for(int i=0;i<d.data.size();i++)
        {
            d.data.pop_back();
        }
    }
    void operator=(histogram &d) // histogram normal assingment operator overloaded
    {
        bins = d.bins;
        data = d.data;
    }
    // move assignment operator commented as two types of assignment operators cannot work together
    // void operator=(histogram &d)
    // {
    //     bins = d.bins;
    //     data = d.data;
    //     for(int i=0;i<d.bins.size();i++)
    //     {
    //         d.bins.pop_back();
    //     }
    //     for(int i=0;i<d.data.size();i++)
    //     {
    //         d.data.pop_back();
    //     }
    // }
    void clear()// for clearing data in histogram
    {
        int size = data.size();
        for(int i=0;i<size;i++)
        {
            data.pop_back();
        }
    }
    void update() // to add more data into histogram
    {
        double d;
        double min = bins.front();
        double max = bins.back();
        cout<<" enter data "<<endl;
        cin>>d;
        if(d>max)
        {
            d = max;
        }
        else if (d<min)
        {
            d = min;
        }
        data.push_back(d);
    }
    void setcolor(int fg, int bg) {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), (bg << 4) | fg);
    }
    void graph()// to graph histogram in different colors
    {
        vector <int> colors;
        for(int y=0;y<bins.size();y++)
        {
            colors.push_back(y+2);
        }
        for(int i=0;i<bins.size()-1;i++)
        {
            cout<<"data values from the range "<<bins[i]<<" till before "<<bins[i+1]<<endl;
            for(int j=0;j<data.size();j++)
            {
                if(bins[i]<=data[j] && bins[i+1]>data[j])
                {
                    setcolor(colors[i],colors[i]);
                    cout<<" ";
                }
            }
            setcolor(7, 0);
            cout<<endl;
        }
    }
   friend ostream& operator<<(ostream& out, histogram &h);
};
ostream& operator<<(ostream& out, histogram &h)// to output data in each histogram range
{
    for(int i=0;i<h.bins.size()-1;i++)
    {
        out<<"data values from the range "<<h.bins[i]<<" till before "<<h.bins[i+1]<<endl;
        for(int j=0;j<h.data.size();j++)
        {
            if(h.bins[i]<=h.data[j] && h.bins[i+1]>h.data[j])
            {
                out<<h.data[j]<<endl;
            }
        }
    }
    return out;
}
int main()
{
    char a='r';
    vector <double> v1;
    double input;
    double prev=-99999999999;
    // firstly asking the ranges of histogram monotonically
    do{
        t:
        cout<<"enter values for histogram ranges monotonically  "<<endl;
        cin>>input;
        if(input<=prev)
        {
            cout<<"invalid enter again "<<endl;
            goto t;
        }
        else
        {
            prev = input;
            v1.push_back(input);
        }
        cout<<"now enter e if ur done entering or any other char to continue entering  "<<endl;
        cin>>a;
    }while (a!='e');
    histogram h1(v1);
    int ch=-1;
    while(ch!=5)
    {
        // 
        cout<<"WHAT DO U WANNA DO WITH THE HISTOGRAM ?"<<endl;
        cout<<"HIT 1 TO FIRSTLY ADD DATA TO HISTOGRAM "<<endl;
        cout<<"HIT 2 TO DISPLAY COLORFUL GRAPH "<<endl;
        cout<<"HIT 3 TO DISPLAY JUST THE DATA IN HISTOGRAM "<<endl;
        cout<<"HIT 4 TO CLEAR DATA OF HISTOGRAM "<<endl;
        cout<<"HIT 5 TO END PROGRAM "<<endl;
        we:
        cin>>ch;
        if(ch>5 && ch<1)
        {
            cout<<"invalid enter again "<<endl;
            goto we;
        }
        switch(ch)
        {
            case 1:
            {
                h1.update();
                break;
            }
            case 2:
            {
                h1.graph();
                break;
            }
            case 3:
            {
                cout<<h1;
                break;
            }
            case 4:
            {
                h1.clear();
                break;
            }
            default:
            {
                cout<<"THANK YOU PROGRAM ENDED "<<endl;
            }
        }
    }
}

