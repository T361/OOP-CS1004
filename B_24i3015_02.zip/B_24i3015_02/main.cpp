#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <math.h>
using namespace std;
// 24i-3015 , Taimoor Shaukat , BSE-B
// firstly defining all of the structs needed in the program

struct employee
{
	int eid;
	char *ename;
	double salary;
};
struct product
{
	char *sku;
	char *pname;
	double unitprice;
};

// ONLY USING THIS FOR CLUSTERING AND FORECAST
struct storeanalytics
{					   // randomize in program
	double totalsales; // less weight then profit
	double totaloperationalcost;
	double profit; // more weight in ranking
	string month;  // analytics of which month
};

// ONLY USING THIS FOR CLUSTERING AND FORECAST
struct storeforecast
{
	char *month;
	double predictedsales; // the predicted sales of the month are entered
						   // show confidence level for the prediction and warning flag if confidence level is lower than 50 percent
};
struct store;
struct salesdata;

// ONLY USING THIS FOR CLUSTERING AND FORECAST
struct salesdata
{			// randomize in program
	int id; // not used , redundant
	product *p;
	string date; // month !!!!!!
	string time; // use of only one of the attributes , the other is redundant
	double totalsaleamount;
};

struct geocoordinates
{
	double glat;
	double glong;
};
struct store
{
	char *sname; // read from file
	int sid;	 //  from file
	geocoordinates location;
	double smonthlycost; // from file
	employee manager;
	employee *staff;
	storeanalytics sa[24];		  // made for analytics     USING THIS!!!!!!!!!!!!
	storeforecast sf;			  // made for forecasting    USING THIS!!!!!!!!!111
	int customercountmonthly[24]; // ranomize in program
	int numberofproducts;
	salesdata *data;
	double totalprofit = 0;
	double totalgrowth = 0;
	double totaloperationcost = 0;
	double averagemonthlyprofit;
	double averagemonthlysales;
	int weight = 0;
	int incluster = 1;
	int bar = 0;
};

// USE THIS IN RANKING!!!!!!!!!!!!!!!!!!!!
struct report
{						 // rank using totalannualsales,average monthly revenue over last year , profitablility(revenue-operating cost)
	store *topstores;	 // top 10 stores based on overall ranking
	store *bottomstores; // bottom 5 stores
	report()
	{
		topstores = new store[10]; // allocating ranking arrays already before
		bottomstores = new store[5];
	}
	// Destructor to free memory
	~report()
	{
		delete[] topstores;
		delete[] bottomstores;
	}
}; // algorithim for ranking using weight , sort rankings by different criterias,

string randommonth()
{
	string months[] = {
		"January", "February", "March", "April", "May", "June",
		"July", "August", "September", "October", "November", "December"};

	return months[rand() % 12]; // random month picked from 0 to 11th index;
}

void generatestore(store shop[100])
{
	string months[] = {
		"January", "February", "March", "April", "May", "June",
		"July", "August", "September", "October", "November", "December"};
	for (int q = 0; q < 100; q++)
	{
		for (int h = 0; h < 24; h++)
		{
			shop[q].sa[h].month = months[h % 12]; // intialising the store analytics months for each month twice
		}
	}
	int max = 0;
	int min = 400;
	for (int y = 0; y < 100; y++)
	{
		for (int m = 0; m < 24; m++)
		{
			shop[y].customercountmonthly[m] = min + rand() % (max - min + 1);
		}
	}
	// store grabbing
	int i = 0;
	int index = 0;
	ifstream infile("storedata.txt");
	if (infile.is_open())
	{
		string line;
		while (getline(infile, line) && i < 100)
		{
			if (index == 0)
			{
				shop[i].sname = new char[line.length() + 1];
				strcpy(shop[i].sname, line.c_str());
			}
			else if (index == 1)
			{
				shop[i].sid = stoi(line);
			}
			else if (index == 2)
			{
				shop[i].smonthlycost = stod(line);
			}
			else if (index == 3)
			{
				shop[i].numberofproducts = stoi(line);
				shop[i].data = new salesdata[shop[i].numberofproducts];
				i++;
			}
			index = (index + 1) % 4; // as after every four lines next stores data comes
		}
		infile.close();
	}
	else
	{
		cout << "file not available" << endl;
	}
	// coordinates grabbing
	int j = 0;
	int jindex = 0;
	ifstream cofile("coordinatesdata.txt");
	if (cofile.is_open())
	{
		string zine;
		while (getline(cofile, zine) && j < 100)
		{
			if (jindex == 0)
			{
				shop[j].location.glat = stod(zine);
			}
			else if (jindex == 1)
			{
				shop[j].location.glong = stod(zine);
				j++;
			}
			jindex = (jindex + 1) % 2;
		}
		cofile.close();
	}
	else
	{
		cout << "file not available" << endl;
	}
	// staff grabbing
	int x = 0;
	int xindex = 0;
	ifstream pofile("staffdata.txt");
	if (pofile.is_open())
	{
		string wine;
		while (getline(pofile, wine) && x < 100)
		{
			if (xindex == 0)
			{
				shop[x].staff = new employee;
				shop[x].staff->eid = stoi(wine);
			}
			else if (xindex == 1)
			{
				shop[x].staff->ename = new char[wine.length() + 1];
				strcpy(shop[x].staff->ename, wine.c_str());
			}
			else if (xindex == 2)
			{
				shop[x].staff->salary = stod(wine);
				x++;
			}
			xindex = (xindex + 1) % 3;
		}
		pofile.close();
	}
	else
	{
		cout << "not found" << endl;
	}
	// manager grabbing
	int y = 0;
	int yindex = 0;
	ifstream yofile("managersdata.txt");
	if (yofile.is_open())
	{
		string yine;
		while (getline(yofile, yine) && y < 100)
		{
			if (yindex == 0)
			{
				shop[y].manager.eid = stoi(yine);
			}
			else if (yindex == 1)
			{
				shop[y].manager.ename = new char[yine.length() + 1];
				strcpy(shop[y].manager.ename, yine.c_str());
			}
			else if (yindex == 2)
			{
				shop[y].manager.salary = stod(yine);
				y++;
			}
			yindex = (yindex + 1) % 3;
		}
		yofile.close();
	}
	else
	{
		cout << "not found" << endl;
	}
	//  product data
	int r = 0;
	int pro = 0;
	int rindex = 0;
	int maxi = 9999.99;
	int mini = 12345.6;
	ifstream rofile("productdata.txt");
	if (rofile.is_open())
	{
		string rine;
		while (getline(rofile, rine) && r < 100 && pro < shop[r].numberofproducts)
		{

			shop[r].data->p = new product[shop[r].numberofproducts];
			if (rindex == 0)
			{
				shop[r].data->p[pro].sku = new char[rine.length() + 1];
				strcpy(shop[r].data->p[pro].sku, rine.c_str());
			}
			else if (rindex == 1)
			{
				shop[r].data->p[pro].pname = new char[rine.length() + 1];
				strcpy(shop[r].data->p[pro].pname, rine.c_str());
			}
			else if (rindex == 2)
			{
				shop[r].data->p[pro].unitprice = stod(rine);
				r++;
				pro++;
			}
			rindex = (rindex + 1) % 3;
		}
		rofile.close();
	}
	else
	{
		cout << " file not found" << endl;
	}
	// STORE ANALYTICS;
	int v = 0;
	int vindex = 0;
	string hine;
	ifstream tfile("totalsales.txt");
	if (tfile.is_open())
	{
		while (getline(tfile, hine))
		{
			shop[vindex].sa[v].totalsales = stod(hine);
			v++;
			if (v == 24)
			{
				v = 0;
				vindex++;
			}
			if (vindex == 100)
			{
				break;
			}
		}
		tfile.close();
	}
	else
	{
		cout << "file not found " << endl;
	}
	int vr = 0;
	int vrindex = 0;
	string hrine;
	ifstream trfile("operationalcosts.txt");
	if (trfile.is_open())
	{
		while (getline(trfile, hrine))
		{
			shop[vrindex].sa[vr].totaloperationalcost = stod(hrine);
			vr++;
			if (vr == 24)
			{
				vr = 0;
				vrindex++;
			}
			if (vrindex == 100)
			{
				break;
			}
		}
		trfile.close();
	}
	else
	{
		cout << "file not there" << endl;
	}

	for (int q = 0; q < 100; q++)
	{
		for (int h = 0; h < 24; h++)
		{
			shop[q].sa[h].profit = shop[q].sa[h].totalsales - shop[q].sa[h].totaloperationalcost;
		}
	}
}
void forecasting(store shop[100])// using average monthly sales to forecast next months
{

	for (int u = 0; u < 100; u++)
	{
		double sum = 0;
		for (int r = 0; r < 24; r++)
		{
			sum += shop[u].sa[r].totalsales;
		}
		shop[u].averagemonthlysales = sum / 24;
	}

	for (int z = 0; z < 100; z++)
	{
		string march = "march2025";
		cout << "FORECAST FOR NEXT MONTH SALES(MARCH 2025) OF STORE  " << shop[z].sname << " is " << shop[z].averagemonthlysales << endl;
		shop[z].sf.predictedsales = shop[z].averagemonthlysales;
		shop[z].sf.month = new char[11];
		strcpy(shop[z].sf.month, march.c_str());
		int min, max, temp;
		min = shop[z].sa[0].totalsales;
		max = shop[z].sa[23].totalsales;
		if (min > max)
		{
			temp = min;
			min = max;
			max = min;
		}
		if (shop[z].averagemonthlysales >= min && shop[z].averagemonthlysales <= max)
		{
			cout << "CONFIDENCE LEVEL IN PREDICTION IS 75% " << endl;
		}
		else if (shop[z].averagemonthlysales > max)
		{
			cout << "CONFIDENCE LEVEL IN PREDICTION IS 25% " << endl;
			cout << "warning a drop in sales may be incoming here" << endl;
		}
		else if (shop[z].averagemonthlysales < min)
		{
			cout << "CONFIDENCE LEVEL IN PREDICTION IS 50% " << endl;
		}
	}
	for (int z = 0; z < 100; z++)
	{
		delete shop[z].sf.month;
	}
}
void performance(store shop[100])// using sorting to rank according to different attributes
{

	for (int y = 0; y < 100; y++)
	{
		for (int t = 0; t < 24; t++)
		{
			shop[y].totalprofit += shop[y].sa[t].profit;
			shop[y].totaloperationcost += shop[y].sa[t].totaloperationalcost;
		}
	}

	for (int u = 0; u < 100; u++)
	{
		double sum = 0;
		for (int r = 0; r < 12; r++)
		{
			sum += shop[u].sa[r].profit;
		}
		shop[u].averagemonthlyprofit = sum / 12;
	}

	store temp3;
	for (int i = 0; i < 100 - 1; i++)
	{
		for (int j = 0; j < 100 - i - 1; j++)
		{
			if (shop[j].averagemonthlyprofit < shop[j + 1].averagemonthlyprofit)
			{
				temp3 = shop[j];
				shop[j] = shop[j + 1];
				shop[j + 1] = temp3;
			}
		}
	}
	cout << "TOP TEN BEST URBANEASE STORE REGARDING AVERAGE MONTHLY PROFIT FOR THE LAST ONE YEARS" << endl;
	for (int i = 0; i < 10; i++)
	{
		shop[i].weight = 1;
		cout << shop[i].sname << " AVERAGE MONTHLY COST FOR LAST ONE YEAR " << shop[i].averagemonthlyprofit << endl;
	}
	cout << endl;
	cout << "BOTTOM FIVE WORST URBANEASE STORE REGARDING AVERAGE MONTHLY PROFIT FOR THE LAST ONE YEARS" << endl;
	for (int i = 95; i < 100; i++)
	{
		shop[i].weight = -1;
		cout << shop[i].sname << " AVERAGE MONTHLY COST FOR LAST ONE YEAR " << shop[i].averagemonthlyprofit << endl;
	}
	cout << endl;
	store temp2;
	for (int i = 0; i < 100 - 1; i++)
	{
		for (int j = 0; j < 100 - i - 1; j++)
		{
			if (shop[j].totaloperationcost < shop[j + 1].totaloperationcost)
			{
				temp2 = shop[j];
				shop[j] = shop[j + 1];
				shop[j + 1] = temp2;
			}
		}
	}
	cout << "TOP TEN BEST URBANEASE STORE REGARDING PROFITTABILITY FOR THE LAST TWO YEARS" << endl;
	for (int i = 90; i < 100; i++)
	{
		shop[i].weight = 2;
		cout << shop[i].sname << " TOTAL OPERATIONAL COST FOR LAST TWO YEARS " << shop[i].totaloperationcost << endl;
	}
	cout << endl;
	cout << "BOTTOM FIVE WORST URBANEASE STORE REGARDING TOTAL PROFITABILITY FOR THE LAST TWO YEARS" << endl;
	for (int i = 0; i < 5; i++)
	{
		shop[i].weight = -2;
		cout << shop[i].sname << " TOTAL OPERATIONAL COST FOR LAST TWO YEARS " << shop[i].totaloperationcost << endl;
	}
	cout << endl;

	store temp;
	for (int i = 0; i < 100 - 1; i++)
	{
		for (int j = 0; j < 100 - i - 1; j++)
		{
			if (shop[j].totalprofit < shop[j + 1].totalprofit)
			{
				temp = shop[j];
				shop[j] = shop[j + 1];
				shop[j + 1] = temp;
			}
		}
	}
	cout << "OVERALL RANKING" << endl;
	cout << "TOP TEN BEST URBANEASE STORE REGARDING TOTAL PROFIT FOR THE LAST TWO YEARS" << endl;
	for (int i = 0; i < 10; i++)
	{
		shop[i].weight = 3;
		cout << shop[i].sname << " TOTAL PROFIT FOR LAST TWO YEARS " << shop[i].totalprofit << endl;
	}
	cout << endl;
	cout << "BOTTOM FIVE WORST URBANEASE STORE REGARDING TOTAL PROFIT FOR THE LAST TWO YEARS" << endl;
	for (int i = 95; i < 100; i++)
	{
		shop[i].weight = -3;
		cout << shop[i].sname << " TOTAL PROFIT FOR LAST TWO YEARS " << shop[i].totalprofit << endl;
	}
	cout << endl;
	cout << "STORES NOW SORTED ACCORDING TO OVERALL BEST RANKING , TOP 10 OVERALL AND BOTTOM 5 OVERALL SAVED IN REPORT" << endl;
}

struct centroid
{					   // use in loop for centroid calculation
	int distance;	   // for first cluster distance from one specific store
	double totalsales; // for second subcluster totalsales in comparison to one specfic store
};
struct subcluster
{
	char *id;
	char *name;
	store *storeslist;
	centroid subcenter;
};
struct cluster
{
	char *id;
	char *name;
	subcluster *subclusterlist;
	centroid center;
};
void clusterbargraph(store shop[100], cluster *clus1, cluster *clus2)// outputting each clusters graph
{
	for (int u = 0; u < 100; u++)
	{
		double sum = 0;
		for (int r = 0; r < 24; r++)
		{
			sum += shop[u].sa[r].profit;
		}
		shop[u].averagemonthlyprofit = sum / 24;
	}
	store temp3;
	for (int i = 0; i < 100 - 1; i++)
	{
		for (int j = 0; j < 100 - i - 1; j++)
		{
			if (shop[j].averagemonthlyprofit < shop[j + 1].averagemonthlyprofit)
			{
				temp3 = shop[j];
				shop[j] = shop[j + 1];
				shop[j + 1] = temp3;
			}
		}
	}

	int maxval = shop[0].averagemonthlyprofit;
	int barwidth = 80;
	int factor = maxval / barwidth;

	string cname1 = "close to most profitable urbanease ";
	string cname2 = "far from most profitable urbanease ";
	string cname3 = "close to most profitable and top performer"; // out put theses
	string cname4 = "close to most profitable and low performer"; // thesess
	string cname5 = "far from most profitable and top performer"; // thesess
	string cname6 = "far from most profitable and low performer"; // theses

	string cid1 = "1";
	string cid2 = "2";
	string cid3 = "3";
	string cid4 = "4";
	string cid5 = "5";
	string cid6 = "6";

	clus1->name = new char[100];
	strcpy(clus1->name, cname1.c_str());

	clus2->name = new char[100];
	strcpy(clus2->name, cname2.c_str());

	clus1->subclusterlist = new subcluster[2];
	clus2->subclusterlist = new subcluster[2];

	clus1->subclusterlist[0].name = new char[100];
	strcpy(clus1->subclusterlist[0].name, cname3.c_str());

	clus1->subclusterlist[1].name = new char[100];
	strcpy(clus1->subclusterlist[1].name, cname4.c_str());

	clus2->subclusterlist[0].name = new char[100];
	strcpy(clus2->subclusterlist[0].name, cname5.c_str());

	clus2->subclusterlist[1].name = new char[100];
	strcpy(clus2->subclusterlist[1].name, cname6.c_str());

	clus1->id = new char[350];
	strcpy(clus1->id, cid1.c_str());

	clus2->id = new char[350];
	strcpy(clus2->id, cid2.c_str());

	clus1->subclusterlist[0].id = new char[350];
	strcpy(clus1->subclusterlist[0].id, cid3.c_str());

	clus1->subclusterlist[1].id = new char[350];
	strcpy(clus1->subclusterlist[1].id, cid4.c_str());

	clus2->subclusterlist[0].id = new char[350];
	strcpy(clus2->subclusterlist[0].id, cid5.c_str());

	clus2->subclusterlist[1].id = new char[350];
	strcpy(clus2->subclusterlist[1].id, cid6.c_str());

	double d = 42.2;
	clus1->center.distance = 42;
	clus2->center.distance = 999999;
	clus1->center.totalsales = shop[0].averagemonthlyprofit;
	clus2->center.totalsales = shop[49].averagemonthlyprofit;

	clus1->subclusterlist[0].storeslist = new store[100];
	clus1->subclusterlist[1].storeslist = new store[100];
	clus2->subclusterlist[0].storeslist = new store[100];
	clus2->subclusterlist[1].storeslist = new store[100];
	int x = 0;
	int j = 0;
	int k = 0;
	int l = 0;
	for (int i = 0; i < 100; i++)
	{
		double withinrange = sqrt(pow(shop[i].location.glat - shop[0].location.glat, 2) + pow(shop[i].location.glong - shop[0].location.glong, 2));
		if (withinrange <= clus1->center.distance)
		{
			if (shop[i].averagemonthlyprofit >= clus2->center.totalsales)
			{
				clus1->subclusterlist[0].storeslist[x] = shop[i];
				clus1->subclusterlist[0].storeslist[x].incluster = 1;
				x++;
			}
			else
			{
				clus1->subclusterlist[1].storeslist[j] = shop[i];
				clus1->subclusterlist[1].storeslist[j].incluster = 1;
				j++;
			}
		}
		else
		{
			if (shop[i].averagemonthlyprofit >= clus2->center.totalsales)
			{
				clus2->subclusterlist[0].storeslist[k] = shop[i];
				clus2->subclusterlist[0].storeslist[k].incluster = 1;
				k++;
			}
			else
			{
				clus2->subclusterlist[1].storeslist[l] = shop[i];
				clus2->subclusterlist[1].storeslist[l].incluster = 1;
				l++;
			}
		}
	}

	cout << clus1->subclusterlist[0].name << endl;
	for (int i = 0; i < x; i++)
	{
		if (clus1->subclusterlist[0].storeslist[i].incluster == 1)
		{
			cout << clus1->subclusterlist[0].storeslist[i].sname << ": ";
			if (clus1->subclusterlist[0].storeslist[i].averagemonthlyprofit == maxval)
			{
				for (int t = 0; t < 1; t++)
				{
					for (int w = 0; w < maxval; w++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
			else
			{
				for (int t = 0; t < 1; t++)
				{
					for (int w = 0; w < clus1->subclusterlist[0].storeslist[i].averagemonthlyprofit / factor; w++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
		}
	}

	cout << clus1->subclusterlist[1].name << endl;
	for (int i = 0; i < j; i++)
	{
		if (clus1->subclusterlist[1].storeslist[i].incluster == 1)
		{
			cout << clus1->subclusterlist[1].storeslist[i].sname << ": ";
			if (clus1->subclusterlist[1].storeslist[i].averagemonthlyprofit == maxval)
			{
				for (int t = 0; t < 1; t++)
				{
					for (int w = 0; w < maxval; w++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
			else
			{
				for (int t = 0; t < 1; t++)
				{
					for (int w = 0; w < clus1->subclusterlist[1].storeslist[i].averagemonthlyprofit / factor; w++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
		}
	}
	cout << clus2->subclusterlist[0].name << endl;
	for (int i = 0; i < k; i++)
	{
		if (clus2->subclusterlist[0].storeslist[i].incluster == 1)
		{
			cout << clus2->subclusterlist[0].storeslist[i].sname << ": ";
			if (clus2->subclusterlist[0].storeslist[i].averagemonthlyprofit == maxval)
			{
				for (int t = 0; t < 1; t++)
				{
					for (int w = 0; w < maxval; w++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
			else
			{
				for (int t = 0; t < 1; t++)
				{
					for (int w = 0; w < clus2->subclusterlist[0].storeslist[i].averagemonthlyprofit / factor; w++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
		}
	}
		cout << clus2->subclusterlist[1].name << endl;
		for (int i = 0; i < l; i++)
		{
			if (clus2->subclusterlist[1].storeslist[i].incluster == 1)
			{
				cout << clus2->subclusterlist[1].storeslist[i].sname << ": ";
				if (clus2->subclusterlist[1].storeslist[i].averagemonthlyprofit == maxval)
				{
					for (int t = 0; t < 1; t++)
					{
						for (int w = 0; w < maxval; w++)
						{
							cout << "*";
						}
					}
					cout << endl;
				}
				else
				{
					for (int t = 0; t < 1; t++)
					{
						for (int w = 0; w < clus2->subclusterlist[1].storeslist[i].averagemonthlyprofit / factor; w++)
						{
							cout << "*";
						}
					}
					cout << endl;
				}
			}
		}
	
	delete[] clus1->name;
	delete[] clus2->name;
	delete[] clus1->subclusterlist;
	delete[] clus2->subclusterlist;
	delete[] clus1->subclusterlist[0].name;
	delete[] clus1->subclusterlist[1].name;
	delete[] clus2->subclusterlist[0].name;
	delete[] clus2->subclusterlist[1].name;
	delete[] clus1->id;
	delete[] clus2->id;
	delete[] clus1->subclusterlist[0].id;
	delete[] clus1->subclusterlist[1].id;
	delete[] clus2->subclusterlist[0].id;
	delete[] clus2->subclusterlist[1].id;
	delete[] clus1->subclusterlist[0].storeslist;
	delete[] clus1->subclusterlist[1].storeslist;
	delete[] clus2->subclusterlist[0].storeslist;
	delete[] clus2->subclusterlist[1].storeslist;
}
void clustering(store shop[100], cluster *clus1, cluster *clus2)// clustring by first
{// making clusters to those nearest to the most profitable store , nearest is defined by a thereshold
// then from those two clusters making further two clusters of each of those most profitable and closest to most profitable
// and those performing or not performing near or close to the top performer
	for (int u = 0; u < 100; u++)
	{
		double sum = 0;
		for (int r = 0; r < 24; r++)
		{
			sum += shop[u].sa[r].profit;
		}
		shop[u].averagemonthlyprofit = sum / 24;
	}
	store temp3;
	for (int i = 0; i < 100 - 1; i++)
	{
		for (int j = 0; j < 100 - i - 1; j++)
		{
			if (shop[j].averagemonthlyprofit < shop[j + 1].averagemonthlyprofit)
			{
				temp3 = shop[j];
				shop[j] = shop[j + 1];
				shop[j + 1] = temp3;
			}
		}
	}
	string cname1 = "close to most profitable urbanease ";
	string cname2 = "far from most profitable urbanease ";
	string cname3 = "close to most profitable and top performer"; // out put theses
	string cname4 = "close to most profitable and low performer"; // thesess
	string cname5 = "far from most profitable and top performer"; // thesess
	string cname6 = "far from most profitable and low performer"; // theses

	string cid1 = "1";
	string cid2 = "2";
	string cid3 = "3";
	string cid4 = "4";
	string cid5 = "5";
	string cid6 = "6";

	clus1->name = new char[100];
	strcpy(clus1->name, cname1.c_str());

	clus2->name = new char[100];
	strcpy(clus2->name, cname2.c_str());

	clus1->subclusterlist = new subcluster[2];
	clus2->subclusterlist = new subcluster[2];

	clus1->subclusterlist[0].name = new char[100];
	strcpy(clus1->subclusterlist[0].name, cname3.c_str());

	clus1->subclusterlist[1].name = new char[100];
	strcpy(clus1->subclusterlist[1].name, cname4.c_str());

	clus2->subclusterlist[0].name = new char[100];
	strcpy(clus2->subclusterlist[0].name, cname5.c_str());

	clus2->subclusterlist[1].name = new char[100];
	strcpy(clus2->subclusterlist[1].name, cname6.c_str());

	clus1->id = new char[350];
	strcpy(clus1->id, cid1.c_str());

	clus2->id = new char[350];
	strcpy(clus2->id, cid2.c_str());

	clus1->subclusterlist[0].id = new char[350];
	strcpy(clus1->subclusterlist[0].id, cid3.c_str());

	clus1->subclusterlist[1].id = new char[350];
	strcpy(clus1->subclusterlist[1].id, cid4.c_str());

	clus2->subclusterlist[0].id = new char[350];
	strcpy(clus2->subclusterlist[0].id, cid5.c_str());

	clus2->subclusterlist[1].id = new char[350];
	strcpy(clus2->subclusterlist[1].id, cid6.c_str());

	double d = 42.2;
	clus1->center.distance = 42;
	clus2->center.distance = 999999;
	clus1->center.totalsales = shop[0].averagemonthlyprofit;
	clus2->center.totalsales = shop[49].averagemonthlyprofit;

	clus1->subclusterlist[0].storeslist = new store[100];
	clus1->subclusterlist[1].storeslist = new store[100];
	clus2->subclusterlist[0].storeslist = new store[100];
	clus2->subclusterlist[1].storeslist = new store[100];
	int x = 0;
	int j = 0;
	int k = 0;
	int l = 0;
	for (int i = 0; i < 100; i++)
	{
		double withinrange = sqrt(pow(shop[i].location.glat - shop[0].location.glat, 2) + pow(shop[i].location.glong - shop[0].location.glong, 2));
		if (withinrange <= clus1->center.distance)
		{
			if (shop[i].averagemonthlyprofit >= clus2->center.totalsales)
			{
				clus1->subclusterlist[0].storeslist[x] = shop[i];
				clus1->subclusterlist[0].storeslist[x].incluster = 1;
				x++;
			}
			else
			{
				clus1->subclusterlist[1].storeslist[j] = shop[i];
				clus1->subclusterlist[1].storeslist[j].incluster = 1;
				j++;
			}
		}
		else
		{
			if (shop[i].averagemonthlyprofit >= clus2->center.totalsales)
			{
				clus2->subclusterlist[0].storeslist[k] = shop[i];
				clus2->subclusterlist[0].storeslist[k].incluster = 1;
				k++;
			}
			else
			{
				clus2->subclusterlist[1].storeslist[l] = shop[i];
				clus2->subclusterlist[1].storeslist[l].incluster = 1;
				l++;
			}
		}
	}

	cout << clus1->subclusterlist[0].name << endl;
	for (int i = 0; i < x; i++)
	{
		if (clus1->subclusterlist[0].storeslist[i].incluster == 1)
		{
			cout << clus1->subclusterlist[0].storeslist[i].sname << endl;
			cout << clus1->subclusterlist[0].storeslist[i].averagemonthlyprofit << endl;
		}
	}
	cout << endl;
	cout << clus1->subclusterlist[1].name << endl;
	for (int i = 0; i < j; i++)
	{
		if (clus1->subclusterlist[1].storeslist[i].incluster == 1)
		{
			cout << clus1->subclusterlist[1].storeslist[i].sname << endl;
			cout << clus1->subclusterlist[1].storeslist[i].averagemonthlyprofit << endl;
		}
	}
	cout << endl;
	cout << clus2->subclusterlist[0].name << endl;
	for (int i = 0; i < k; i++)
	{
		if (clus2->subclusterlist[0].storeslist[i].incluster == 1)
		{
			cout << clus2->subclusterlist[0].storeslist[i].sname << endl;
			cout << clus2->subclusterlist[0].storeslist[i].averagemonthlyprofit << endl;
		}
	}
	cout << endl;
	cout << clus2->subclusterlist[1].name << endl;
	for (int i = 0; i < l; i++)
	{
		if (clus2->subclusterlist[1].storeslist[i].incluster == 1)
		{
			cout << clus2->subclusterlist[1].storeslist[i].sname << endl;
			cout << clus2->subclusterlist[1].storeslist[i].averagemonthlyprofit << endl;
		}
	}
	cout << endl;
	delete[] clus1->name;
	delete[] clus2->name;
	delete[] clus1->subclusterlist;
	delete[] clus2->subclusterlist;
	delete[] clus1->subclusterlist[0].name;
	delete[] clus1->subclusterlist[1].name;
	delete[] clus2->subclusterlist[0].name;
	delete[] clus2->subclusterlist[1].name;
	delete[] clus1->id;
	delete[] clus2->id;
	delete[] clus1->subclusterlist[0].id;
	delete[] clus1->subclusterlist[1].id;
	delete[] clus2->subclusterlist[0].id;
	delete[] clus2->subclusterlist[1].id;
	delete[] clus1->subclusterlist[0].storeslist;
	delete[] clus1->subclusterlist[1].storeslist;
	delete[] clus2->subclusterlist[0].storeslist;
	delete[] clus2->subclusterlist[1].storeslist;
}
void forecastgraph(store shop[100])// drawing the bargraph of each stores forecasted sales
{
	for(int p=0;p<100;p++)
	{
		shop[p].averagemonthlysales =0;
	}
	for (int u = 0; u < 100; u++)
	{
		double sum = 0;
		for (int r = 0; r < 24; r++)
		{
			sum += shop[u].sa[r].totalsales;
		}
		shop[u].averagemonthlysales = sum / 24;
	}
	store temp;
		for (int i = 0; i < 100 - 1; i++)
		{
			for (int j = 0; j < 100 - i - 1; j++)
			{
				if (shop[j].averagemonthlysales < shop[j + 1].averagemonthlysales)
				{
					temp = shop[j];
					shop[j] = shop[j + 1];
					shop[j + 1] = temp;
				}
			}
		}
	int maxval = shop[0].averagemonthlysales;
	int barwidth = 80;
	int factor = maxval / barwidth;
	for (int z = 0; z < 100; z++)
	{
		string march = "march2025";
		cout << "FORECAST FOR NEXT MONTH SALES(MARCH 2025) OF STORE  " << shop[z].sname << " is :" <<endl;
		if(shop[z].averagemonthlysales==maxval)
		{
			for(int k=0;k<1;k++)
			{
				for(int l=0;k<barwidth;l++)
				{
					cout<<"*";
				}
			}
		}
		else
		{
			for (int k = 0; k < 1; k++)
				{
					for (int l = 0; l < shop[z].averagemonthlysales / factor; l++)
					{
						cout << "*";
					}
				}
				cout << endl;
		}
		shop[z].sf.predictedsales = shop[z].averagemonthlysales;
		shop[z].sf.month = new char[11];
		strcpy(shop[z].sf.month, march.c_str());
		int min, max, temp;
		min = shop[z].sa[0].totalsales;
		max = shop[z].sa[23].totalsales;
		if (min > max)
		{
			temp = min;
			min = max;
			max = min;
		}
		if (shop[z].averagemonthlysales >= min && shop[z].averagemonthlysales <= max)
		{
			cout << "CONFIDENCE LEVEL IN PREDICTION IS 75% " << endl;
		}
		else if (shop[z].averagemonthlysales > max)
		{
			cout << "CONFIDENCE LEVEL IN PREDICTION IS 25% " << endl;
			cout << "warning a drop in sales may be incoming here" << endl;
		}
		else if (shop[z].averagemonthlysales < min)
		{
			cout << "CONFIDENCE LEVEL IN PREDICTION IS 50% " << endl;
		}
	}
	for (int z = 0; z < 100; z++)
	{
		delete shop[z].sf.month;
	}
}
void bargraph(store shop[100], cluster *clus1, cluster *clus2) // bargraphs are drawn by assigning weight to max value
{// and then scaling every other bargraph accordingly
// drawing bargraph according to scale factor
	for (int y = 0; y < 100; y++)
	{
		for (int t = 0; t < 24; t++)
		{
			shop[y].totalprofit += shop[y].sa[t].profit;
		}
	}

	for (int u = 0; u < 100; u++)
	{
		double sum = 0;
		for (int r = 0; r < 24; r++)
		{
			sum += shop[u].sa[r].profit;
		}
		shop[u].averagemonthlyprofit = sum / 24;
	}
	cout << "which way would you like data to be visualised,  enter " << endl;
	cout << "1. to visualise according total profit of each store for last two years" << endl;
	cout << "2. to visualise according to average monthly profit of each store for last two years" << endl;
	cout << "3. to visualise one store according to total profit for last two years" << endl;
	cout << "4. to visualise one store according to average monthly profit for last two years" << endl;
	cout << "5. to visualise all stores according to clusters" << endl;
	cout<< "6. to visualise forecast of sales of all stores for next month"<<endl;
no:
	int cho = -1;
eno:
	cin >> cho;
	if (cho > 6 || cho < 1)
	{
		cout << "INVALID" << endl;
		goto eno;
	}
	switch (cho)
	{
	case 1:
	{
		store temp;
		for (int i = 0; i < 100 - 1; i++)
		{
			for (int j = 0; j < 100 - i - 1; j++)
			{
				if (shop[j].totalprofit < shop[j + 1].totalprofit)
				{
					temp = shop[j];
					shop[j] = shop[j + 1];
					shop[j + 1] = temp;
				}
			}
		}
		int maxval = shop[0].totalprofit;
		int barwidth = 80;
		int factor = maxval / barwidth;
		for (int j = 0; j < 100; j++)
		{
			if (shop[j].totalprofit == maxval)
			{
				cout << shop[j].sname << ": ";
				for (int k = 0; k < 1; k++)
				{
					for (int l = 0; l < barwidth; l++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
			else
			{
				cout << shop[j].sname << ": ";
				for (int k = 0; k < 1; k++)
				{
					for (int l = 0; l < shop[j].totalprofit / factor; l++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
		}
		break;
	}
	case 2:
	{
		store temp3;
		for (int i = 0; i < 100 - 1; i++)
		{
			for (int j = 0; j < 100 - i - 1; j++)
			{
				if (shop[j].averagemonthlyprofit < shop[j + 1].averagemonthlyprofit)
				{
					temp3 = shop[j];
					shop[j] = shop[j + 1];
					shop[j + 1] = temp3;
				}
			}
		}
		int maxval1 = shop[0].averagemonthlyprofit;
		int barwidth1 = 80;
		int factor1 = maxval1 / barwidth1;
		for (int j = 0; j < 100; j++)
		{
			if (shop[j].averagemonthlyprofit == maxval1)
			{
				cout << shop[j].sname << ": ";
				for (int k = 0; k < 1; k++)
				{
					for (int l = 0; l < barwidth1; l++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
			else
			{
				cout << shop[j].sname << ": ";
				for (int k = 0; k < 1; k++)
				{
					for (int l = 0; l < shop[j].averagemonthlyprofit / factor1; l++)
					{
						cout << "*";
					}
				}
				cout << endl;
			}
		}
		break;
	}
	case 3:
	{
		store temp;
		for (int i = 0; i < 100 - 1; i++)
		{
			for (int j = 0; j < 100 - i - 1; j++)
			{
				if (shop[j].totalprofit < shop[j + 1].totalprofit)
				{
					temp = shop[j];
					shop[j] = shop[j + 1];
					shop[j + 1] = temp;
				}
			}
		}
		int whichstore = 9999;
	hhh:
		cout << "which stores totalprofit for two years would you like to visualise between 1 to 100 inclusive" << endl;
		cin >> whichstore;
		if (whichstore < 1 || whichstore > 100)
		{
			cout << "invalid" << endl;
			goto hhh;
		}
		int index;
		for (int y = 0; y < 100; y++)
		{
			if (shop[y].sid == whichstore)
			{
				index = y;
			}
		}
		int maxval = shop[0].totalprofit;
		int barwidth = 80;
		int factor = maxval / barwidth;
		if (shop[index].totalprofit == maxval)
		{
			cout << shop[index].sname << ": ";
			for (int k = 0; k < 1; k++)
			{
				for (int l = 0; l < barwidth; l++)
				{
					cout << "*";
				}
			}
			cout << endl;
		}
		else
		{
			cout << shop[index].sname << ": ";
			for (int k = 0; k < 1; k++)
			{
				for (int l = 0; l < shop[index].totalprofit / factor; l++)
				{
					cout << "*";
				}
			}
			cout << endl;
		}
		break;
	}
	case 4:
	{
		store temp;
		for (int i = 0; i < 100 - 1; i++)
		{
			for (int j = 0; j < 100 - i - 1; j++)
			{
				if (shop[j].averagemonthlyprofit < shop[j + 1].averagemonthlyprofit)
				{
					temp = shop[j];
					shop[j] = shop[j + 1];
					shop[j + 1] = temp;
				}
			}
		}
		int whichstore = 9999;
	hh:
		cout << "which stores average monthly profit for two years would you like to visualise between 1 to 100 inclusive" << endl;
		cin >> whichstore;
		if (whichstore < 1 || whichstore > 100)
		{
			cout << "invalid" << endl;
			goto hh;
		}
		int index;
		for (int y = 0; y < 100; y++)
		{
			if (shop[y].sid == whichstore)
			{
				index = y;
			}
		}
		int maxval = shop[0].averagemonthlyprofit;
		int barwidth = 80;
		int factor = maxval / barwidth;
		if (shop[index].averagemonthlyprofit == maxval)
		{
			cout << shop[index].sname << ": ";
			for (int k = 0; k < 1; k++)
			{
				for (int l = 0; l < barwidth; l++)
				{
					cout << "*";
				}
			}
			cout << endl;
		}
		else
		{
			cout << shop[index].sname << ": ";
			for (int k = 0; k < 1; k++)
			{
				for (int l = 0; l < shop[index].averagemonthlyprofit / factor; l++)
				{
					cout << "*";
				}
			}
			cout << endl;
		}
		break;
	}
	case 5:
	{
		clusterbargraph(shop, clus1, clus2);
		break;
	}
	case 6:
	{
		forecastgraph(shop);
		break;
	}
	}
}
int main()
{
	srand(time(0));
	store *shops = new store[100];
	report *ranking = new report;
	cluster *clus1 = new cluster;
	cluster *clus2 = new cluster;
	generatestore(shops); // adding generated data from txt file!!!!!!!!!!
	int ch = -1;
	while (ch != 5)
	{
		cout << "URBANEASE : STORE ANALYTICS AND ADVANCED MANAGEMENT SYSTEM" << endl;
		cout << "1 TO PROVIDE SUMMARY FOR EACH CLUSTER FOR STORES YOU HAVE ADDED" << endl; // use of loop
		cout << "2 TO GENERATE STORES PERFORMANCE REPORT WITH TOP 10 OVERALL AND BOTTOM 5 FOR STORES YOUVE ADDED" << endl;
		cout << "3 TO FORECAST SALES OF NEXT MONTH FOR A SPECFIC STORE YOU HAVE ADDED" << endl;
		cout << "4 TO DISPLAY BARGRAPH FOR ONE STORE OR ALL STORES/CLUSTERS " << endl;
		cout << "5 TO EXIT " << endl;
	wrongchoice:
		cout << "ENTER CHOICE " << endl;
		cin >> ch;
		if (ch < 1 || ch > 5)
		{
			cout << "wrong choice " << endl;
			goto wrongchoice;
		}
		switch (ch)
		{
		case 1:
		{
			// summary of each cluster and clustering
			clustering(shops, clus1, clus2);
			break;
		}
		case 2:
		{
			// performance report
			performance(shops);
			for (int i = 0; i < 10; i++)
			{
				ranking->topstores[i] = shops[i]; // IN RANKING PROFIT GIVEN MOST WEIGHT INSIDE PROFIT FUNCTION
			}
			for (int i = 95, j = 0; i < 100; i++, j++)
			{
				ranking->topstores[j] = shops[i];
			}
			for(int i=0;i<100;i++)
			{
				shops[i].totalprofit =0;
				shops[i].totaloperationcost =0;
				shops[i].averagemonthlyprofit =0;
			}
			break;
		}

		case 3:
		{
			// forecast sales for next month for all stores
			forecasting(shops);
			break;
		}

		case 4:
		{
			// display bargraph for all stores and individual stores
			bargraph(shops, clus1, clus2);
			for(int i=0;i<100;i++)
			{
				shops[i].totalprofit =0;
				shops[i].totaloperationcost =0;
				shops[i].averagemonthlyprofit =0;
			}
			break;
		}

		case 5:
		{
			delete[] shops;
			delete ranking;
			delete clus1;
			delete clus2;
			ch = 5;
			cout << "PROGRAM ENDED" << endl;
			break;
		}
		}
	}
}
