// TAIMOOR SHAUKAT , 24i-3015
#include <iostream>
using namespace std;
void CheckEqualSumArrays(int **A1,int **A2,int **A3)
{
	int sum1[2][2]={{0,0},{0,0}};// sum of array 1 n 2
	int sum2[2][2]={{0,0},{0,0}};//sum of array 1 n 3
	int sum3[2][2]={{0,0},{0,0}};// sum of array 2 n 3
	for(int i =0;i<2;i++)
	{
		for(int j=0;j<2;j++)// SUMMING  ALL THREE ARRAYS IN ALL COMBOS
		{
				sum1[i][j]=  *(*(A1+i)+j) + *(*(A2+i)+j);
		}
	}
	for(int i =0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
				sum2[i][j]=  *(*(A1+i)+j) + *(*(A3+i)+j);
		}
	}
	for(int i =0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
				sum3[i][j]=  *(*(A2+i)+j) + *(*(A3+i)+j);
		}
	}
	int s1=0;
	int s2=0;
	int s3=0;
	for(int i=0;i<2;i++)// CHECKING WHICH TWO  SUM MATCHES W WHICH THIRD ARRAY
	{
		for(int j=0;j<2;j++)
		{
			if(sum1[i][j]==*(*(A3+i)+j))
			{
				s1++;
			}
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(sum2[i][j]==*(*(A2+i)+j))
			{
				s2++;
			}
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(sum3[i][j]==*(*(A1+i)+j))
			{
				s3++;
			}
		}
	}
	if(s1==4)
	{
		cout<<"sum of array 1 and 2 is equal to 3rd"<<endl;
	}
	if(s2==4)
	{
		cout<<"sum of array 1 and 3 is equal to 2nd"<<endl;
	}
	if(s3==4)
	{
		cout<<"sum of array 2 and 3 is equal to 1st"<<endl;
	}
	if(s1!=4 && s2!=4 && s3!=4)
	{
		cout<<"no sums are equal to any third array "<<endl;
	}
}
void CheckEqualDifferentArrays(int **A1,int **A2,int **A3)// DOING THE SAME AS THE SUMMING CHECK
{
	int diff1[2][2]={{0,0},{0,0}};// DIFF of array 1 n 2
	int diff2[2][2]={{0,0},{0,0}};//DIFF of array 1 n 3
	int diff3[2][2]={{0,0},{0,0}};// DIFF of array 2 n 3
	for(int i =0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
				diff1[i][j]= -1*(*(*(A1+i)+j) - *(*(A2+i)+j));
		}
	}
	for(int i =0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
				diff2[i][j]=  -1*(*(*(A1+i)+j) - *(*(A3+i)+j));
		}
	}
	for(int i =0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
				diff3[i][j]=  -1*(*(*(A2+i)+j) - *(*(A3+i)+j));
		}
	}
	int d1=0;
	int d2=0;
	int d3=0;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(diff1[i][j]==*(*(A3+i)+j))
			{
				d1++;
			}
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(diff2[i][j]==*(*(A2+i)+j))
			{
				d2++;
			}
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(diff3[i][j]==*(*(A1+i)+j))
			{
				d3++;
			}
		}
	}
	if(d1==4)
	{
		cout<<"difference of array 1 and 2 is equal to 3rd"<<endl;
	}
	if(d2==4)
	{
		cout<<"difference of array 1 and 3 is equal to 2nd"<<endl;
	}
	if(d3==4)
	{
		cout<<"difference of array 2 and 3 is equal to 1st"<<endl;
	}
	if(d1!=4&&d2!=4&&d3!=4)
	{
		cout<<"no differences are equal to any third array"<<endl;
	}
}
void CheckEqualArrays(int **A1,int **A2,int **A3)
{
	int s1=0;
	int s2=0;
	int s3=0;// CHECKING EACH POSSIBLE COMBO OF SAME ARRAYS THAT CAN BE
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(*(*(A1+i)+j)==*(*(A2+i)+j))
			{
				s1++;
			}
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(*(*(A1+i)+j)==*(*(A3+i)+j))
			{
				s2++;
			}
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			if(*(*(A2+i)+j)==*(*(A3+i)+j))
			{
				s3++;
			}
		}
	}
	if(s1==4)
	{
		cout<<"array 1 and 2 are same "<<endl;
	}
	else if(s2==4)
	{
		cout<<"array 1 and 3 are same "<<endl;
	}
	else if(s3==4)
	{
		cout<<"array 2 and 3 are same "<<endl;
	}
	else
	{
		cout<<"no arrays are same "<<endl;
	}
}
void FindSameRows(int **A1,int **A2,int **A3)
{
	int r1;
	for(int i=0,j=1;i<2,j<2;i++,j++)
	{
		r1=0;
		for(int k=0;k<2;k++)
		{
			if(*(*(A1+i)+k)==*(*(A1+j)+k))
			{
				r1++;
			}
		}
		if(r1==2)
		{
			cout<<"ROW "<<i+1<<" ROW "<<j+1<<" OF ARRAY 1 ARE SAME "<<endl;
		}
	}
	int r2;
	for(int i=0,j=1;i<2,j<2;i++,j++)
	{
		r2=0;
		for(int k=0;k<2;k++)
		{
			if(*(*(A2+i)+k)==*(*(A2+j)+k))
			{
				r2++;
			}
		}
		if(r2==2)
		{
			cout<<"ROW "<<i+1<<" ROW "<<j+1<<" OF ARRAY 2 ARE SAME "<<endl;
		}
	}
	int r3;
	for(int i=0,j=1;i<2,j<2;i++,j++)
	{
		r3=0;
		for(int k=0;k<2;k++)
		{
			if(*(*(A3+i)+k)==*(*(A3+j)+k))
			{
				r3++;
			}
		}
		if(r3==2)
		{
			cout<<"ROW "<<i+1<<" ROW "<<j+1<<" OF ARRAY 3 ARE SAME "<<endl;
		}
	}
}
void RotateArrays(int **A1,int **A2,int **A3)
{
	int temp;// FIRST TRANSPOSING EACH MATRIX THEN REVERSING EACH MATRIXS ROWS THEN PRINTING IT 
	for(int i=0;i<2;i++)
	{
		for(int j=i;j<2;j++)
		{
			temp = *(*(A1+i)+j);
			*(*(A1+i)+j) = *(*(A1+j)+i);
			*(*(A1+j)+i) = temp;
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0,k=2-1;j<k;j++,k--)
		{
			temp = *(*(A1+i)+j);
			*(*(A1+i)+j) = *(*(A1+i)+k);
			*(*(A1+i)+k) = temp;
		}
	}
	
	
	for(int i=0;i<2;i++)
	{
		for(int j=i;j<2;j++)
		{
			temp = *(*(A2+i)+j);
			*(*(A2+i)+j) = *(*(A2+j)+i);
			*(*(A2+j)+i) = temp;
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0,k=2-1;j<k;j++,k--)
		{
			temp = *(*(A2+i)+j);
			*(*(A2+i)+j) = *(*(A2+i)+k);
			*(*(A2+i)+k) = temp;
		}
	}
	
	
	for(int i=0;i<2;i++)
	{
		for(int j=i;j<2;j++)
		{
			temp = *(*(A3+i)+j);
			*(*(A3+i)+j) = *(*(A3+j)+i);
			*(*(A3+j)+i) = temp;
		}
	}
	for(int i=0;i<2;i++)
	{
		for(int j=0,k=2-1;j<k;j++,k--)
		{
			temp = *(*(A3+i)+j);
			*(*(A3+i)+j) = *(*(A3+i)+k);
			*(*(A3+i)+k) = temp;
		}
	}
	
	cout<<"ARRAY 1 90 DEGREE CLOCKWISE "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<*(*(A1+i)+j)<<" ";
		}
		cout<<endl;
	}
	
	cout<<"ARRAY 2 90 DEGREE CLOCKWISE "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<*(*(A2+i)+j)<<" ";
		}
		cout<<endl;
	}
	
	cout<<"ARRAY 3 90 DEGREE CLOCKWISE "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<*(*(A3+i)+j)<<" ";
		}
		cout<<endl;
	}
}
int main()
{
	int **A1 = new int*[2];
	int **A2 = new int*[2];
	int **A3 = new int*[2];// DYNAMICALLY MAKING 2 BY 2 MATRIXS AND ASKING THERE ELEMENTS AND THEN OUTPUTTING THEM AND PERFORMING OPERATIONS AND DELETING THEM
	
	for(int i =0;i<2;i++)
	{
		*(A1+i) = new int[2];
		*(A2+i)= new int[2];
		*(A3+i)= new int[2];
	}
	
	cout<<"enter first array elements"<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cin>>*(*(A1+i)+j);
		}
	}
	cout<<"enter second array elements"<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cin>>*(*(A2+i)+j);
		}
	}
	cout<<"enter second array elements"<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cin>>*(*(A3+i)+j);
		}
	}
	
	cout<<"ARRAY 1  "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<*(*(A1+i)+j)<<" ";
		}
		cout<<endl;
	}
	
	cout<<"ARRAY 2  "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<*(*(A2+i)+j)<<" ";
		}
		cout<<endl;
	}
	
	cout<<"ARRAY 3  "<<endl;
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			cout<<*(*(A3+i)+j)<<" ";
		}
		cout<<endl;
	}
	CheckEqualSumArrays(A1,A2,A3);
    CheckEqualDifferentArrays(A1,A2,A3);
    CheckEqualArrays(A1,A2,A3);
    FindSameRows(A1,A2,A3);
    RotateArrays(A1,A2,A3);
    for(int i=0;i<2;i++)
	{
			delete [] A1[i];
			delete [] A2[i];
			delete [] A3[i];
	}
	delete [] A1;
	delete [] A2;
	delete [] A3;
}
