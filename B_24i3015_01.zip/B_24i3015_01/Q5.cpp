// TAIMOOR SHAUKAT , 24i-3015
#include <iostream>
using namespace std;
int main()
{
	int student [999];
	for(int i=0;i<999;i++)// TAKING INPUT INTO A MASSIVE ARRAY OF STUDENT MARKS THEN ALLOCATING A DYNAMIC ARRAY ACCORDING TO THE INPUTS TAKEN INTO THE MASSIVE ARRAY THEN SHIFFTING ALL THE MARKS INTO THAT ARRAY 
	{
		student[i] = -1;
	}
	int ch=9999;
	int index=0;
	while(ch!=-1)
	{
		invalid:
		cout<<"enter students marks or -1 to stop entering "<<endl;
		cin>>ch;
		if(ch<-1)
		{
			cout<<"invalid"<<endl;
			goto invalid;
		}
		else if(ch==-1)
		{
			break;
		}
		else
		{
			student[index] = ch;
			index++;
			
		}
	}
	int *sptr = new int[index];
	for(int j=0;j<index;j++)
	{
		if(student[j]>-1)
		{
			sptr[j] = student[j];
		}
	}
	int done=-2;
	for(int k =0;k<index;k++)// CHECKING THE FREQUENCY OF EACH MARK IN THE DYNAMICALLY ALLOCATED ARRAY AND OUTPUTTING THEM
	{
		int freq=1;
		
		for(int l=0;l<index;l++)
		{
			if(sptr[k]==sptr[l]&&l!=k)
			{
				freq++;
				sptr[l] = -1;// marks out the repeating values
			}
		}
		if(freq>0&&done!=sptr[k]&&sptr[k]>-1)// BEFORE OUTTPUTING CHECKING IF THE NUMBER WHOSE FREQUENCY IS BEING CHECKED HAS BEEN ALREADY CHECKED OR NOT
		{
			done = sptr[k];
			cout<<"THE FREQUENCEY OF "<<sptr[k]<<"'s: "<<freq<<endl;
			sptr[k] =-1;// marks out the number whose frequency is checked
		}
	}
	delete [] sptr;
}

