// TAIMOOR SHAUKAT , 24i-3015
#include <iostream>
using namespace std;
void printbus(int size,char **arr)// FUNCTION USED TO PRINT BUS 
{
	cout<<"BUS SEATS , X DENOTES THOSE SEATS TAKEN "<<endl;
	for(int i= 0;i<size;i++)
	{
		cout<<i+1;
		for(int j = 0;j<4;j++)
		{
			cout<<" "<<arr[i][j];
		}
		cout<<endl;
	}
}
int colseat(char choice)// FUNCTION USED TO CONVERT USERS ENTERED SEAT LETTER TO INDEX OF COLUMNS OF BUS
{
		if(choice=='A')
			{
				return 0;
			}
			else if(choice=='B')
			{
				return 1;
			}
			else if(choice=='C')
			{
				return 2;
			}
			else if(choice=='D')
			{
				return 3;
			}
}
int main()
{
	int size=0;
	char choice;
	int col;
	cout<<"ENTER NUMBER OF ROWS OF THE BUS "<<endl;
	cin>>size;
	char **bus  = new char *[size];// DYNAMICALLY MAKING AN ARRAY WITH USERS ENTERED SIZE OF BUS ROWS
	for(int i=0;i<size;i++)
	{
		bus[i] = new char[4];		
	}
	
	for(int i=0;i<size;i++)
	{
		for(int j = 0;j<4;j++)
		{
			bus[i][j] = 'A'+j;//INTIALISING THE BUS W A B C D SEATS
		}
	}
	
	int row  = 0;
	while(row!=-1)
	{
		printbus(size,bus);
		wrong:
		cout<<"Enter bus row you want to sit in , or -1 to end"<<endl;
		cout<<"rows of bus are till "<<size<<endl;// ASKING FOR BUS ROW CHOICE OR ENDING 
		cin>>row;
		if(row==-1)
		{
			break;
		}
		else if(row< -1 || row >size)
		{
			goto wrong;
		}
		else if(row ==0)
		{
			goto wrong;
		}
		else
		{
			wrongcol:
			cout<<"what seat do you want to sit in A,B,C or D? "<<endl;
			cin>>choice;
			if(choice != 'A' && choice!= 'B' && choice!= 'C' && choice!= 'D') // THEN ASKING COLUMN CHOICE
			{
				goto wrongcol;
			}
			col = colseat(choice);// GETTING INDEX OF COLUMN FROM USERS ENTERED SEAT LETTER
			if(bus[row-1][col]== 'X')
			{
				cout<<"seat already filled"<<endl;// CHECKING IF SEAT ALREADY FILLED IF IT IS THEN GO BACK TO CHOICE
				goto wrong;
			}
			else if(bus[row-1][col]!= 'X')
			{
				bus[row-1][col]= 'X';// FILLING THE SEAT WITH X
			}
		}
	}
	for(int i=0;i<size;i++)
	{
			delete [] bus[i]; // DELETING DYNAMICALLY ALLOCATED BUS
	}
	delete [] bus;
}
