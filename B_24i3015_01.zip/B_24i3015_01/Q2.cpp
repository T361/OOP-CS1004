// TAIMOOR SHAUKAT 24i-3015
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{
	int numberofcandidates,votescasted;
	wrong:
	cout<<"ENTER NUMBER OF CANDIDATES"<<endl;
	cin>>numberofcandidates;
	if(numberofcandidates<0)
	{
		goto wrong;
	}
	string *lastnames = new string [numberofcandidates];
	int *votes = new int [numberofcandidates];// DYNAMICALLY MAKING LAST NAME AND VOTES ARRAY BY ASKING NUMBER OF CANDIDATES
	cout<<"ENTER LAST NAME OF EACH CANDIDATE"<<endl;
	for(int i=0;i<numberofcandidates;i++)
	{
		cin>>lastnames[i];//ENTERING LAST NAMES 
	}
	eee:
	cout<<"ENTER TOTAL NUMBER OF VOTES CASTED "<<endl;
	cin>>votescasted;// ASKING TOTAL NUMBER OF VOTES OF CASTED
	if(votescasted<0)
	{
		goto eee;
	}
	int votesleft = votescasted;
	int vote;
	cout<<"ENTER NUMBER OF VOTES OF EACH CANDIDATE"<<endl;
	for(int j=0;j<numberofcandidates;j++)
	{
		wrongvote:
		cin>>vote;
		if(vote>votesleft || vote<0)
		{
			cout<<"invalid input enter again "<<endl;
			goto wrongvote;
		}
		else
		{
			votesleft = votesleft - vote;
			votes[j] = vote;//ENTERING NUMBER OF VOTES ACCORDING TO VOTES LEFT INT DYNAMIC ARRAY
		}
	}
	cout<<setw(10)<<" Name of Candidate ";cout<<setw(10)<<" Votes Received ";cout<<setw(10)<<" %ofTotal Votes "<<endl;
	for(int k=0;k<numberofcandidates;k++)
	{
		double percent = ((static_cast<double>(votes[k])/votescasted)*100);
		cout<<setw(10)<<" "<<lastnames[k]; cout<<setw(10)<<" "<<votes[k]; cout<<setw(10)<<fixed<<setprecision(5)<<" "<<percent<<endl;// OUTPUTTING ALL DATA
	}
	int max = votes[0];
	string maxname = lastnames[0];
	int index;
	bool winner=true;
	for(int l = 1;l<numberofcandidates;l++)
	{
		if(votes[l]>max)
		{
			max = votes[l];
			maxname = lastnames[l];
			index = l;
			winner = true;
		}
		else if(votes[l] == max)
		{
			winner = false;
		}
	}// CHECKING THE WINNER AND OUTPUTTING IF THERE IS A DEFINITVE WINNER AND OUTPUTTING HIS NAME BY STORING THE NAME INDEX AS BOTH ARRAYS ARE PARRALEL
	if(winner)
	{
		cout<<"THE WINNER OF THE LOCAL ELECTION IS "<<maxname<<endl;
	}
	else
	{
		cout<<"no definitive winner "<<endl;
	}
	delete [] lastnames;
	delete [] votes;
}
