//TAIMOOR SHAUKAT , 24i-3015
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int maxscore(int **matrix,int M,int N,int row,int col,int score)
{
	if(row<M && row>-1&&col<N&&col>-1&&row%2==1)// GOING LEFT OR DOWN IF ROW IS ODD IF THERE ARE NO OBSTACLES THAT IS
	{
		if(col-1>-1 && col-1<N&&*(*(matrix+row)+col-1)==1 )
		{
			score++;
			col--;
			return maxscore(matrix,M,N,row,col,score);
		}
		else if(row+1>-1 && row+1<M&&*(*(matrix+row+1)+col)==1)
		{
			score++;
			row++;
			return maxscore(matrix,M,N,row,col,score);	
		}
		else if(col-1>-1 && col-1<N&&*(*(matrix+row)+col-1)==0)
		{
			col--;
			return maxscore(matrix,M,N,row,col,score);
		}
		else if(row+1>-1 && row+1<M&&*(*(matrix+row+1)+col)==0)
		{
			row++;
			return maxscore(matrix,M,N,row,col,score);
		}
		else
		{
			if(*(*(matrix+0)+0)==1)
			{
				score++;	
			}
			return score;
		}
	}
	else if(row<M && row>-1&&col<N&&col>-1&&row%2==0)// CHECKING THE SAME WITH EVEN ROWS
	{
		if(col+1>-1 && col+1<N&&*(*(matrix+row)+col+1)==1)
		{
			score++;
			col++;
			return maxscore(matrix,M,N,row,col,score);
			
		}
		else if(col+1>-1 && col+1<N&&*(*(matrix+row+1)+col)==1)
		{
			score++;
			row++;
			return maxscore(matrix,M,N,row,col,score);	
		}
		else if(col+1>-1 && col+1<N&&*(*(matrix+row)+col+1)==0)
		{
			col++;
			return maxscore(matrix,M,N,row,col,score);
		}
		else if( row+1>-1 && row+1<M&&*(*(matrix+row+1)+col)==0)
		{
			row++;
			return maxscore(matrix,M,N,row,col,score);
		}
		else
		{
			if(*(*(matrix+0)+0)==1)
			{
				score++;	
			}
			return score;
		}
	}
	else
	{
		if(*(*(matrix+0)+0)==1)// ELSE RETURNING SCORE AND IN EACH RETURN OF SCORE WILL BE PLUS 1 IF FIRST CELL IS ONE
		{
			score++;	
		}
		return score;
	}
	
}
int main()
{
	int M,N;
	srand(time(0));
	invalidrow:
	cout<<"enter number of rows of array"<<endl;
	cin>>M;
	if(M<1)
	{
		cout<<"invalid rows "<<endl;
		goto invalidrow;
	}
	
	invalidcol:
	cout<<"enter number of columns of array"<<endl;
	cin>>N;
	if(N<1)
	{
		cout<<"invalid columns "<<endl;
		goto invalidcol;
	}
	
	int **matrix = new int*[M];
	for(int i=0;i<M;i++)
	{
		*(matrix+i) = new int[N];
	}
	
	for(int i=0;i<M;i++)
	{
		for(int j=0;j<N;j++)
		{
			*(*(matrix+i)+j) = -1 + (rand() %(1-(-1)+1));// RANDOMLY FILLING THE DYNAMICALLY MADE ARRAY WITH NUMBERS BETWEEN -1 AND 1 BUT THE FIRST CELL MUST BE EITHER 0 OR 1
		}
	}
	*(*(matrix+0)+0) = 0 + (rand() %(1-(0)+1));
	
	cout<<"THE MAZE "<<endl;
	for(int i=0;i<M;i++)
	{
		for(int j=0;j<N;j++)
		{
			cout<<" "<<*(*(matrix+i)+j);
		}
		cout<<endl;
	}
	
	int max=maxscore(matrix,M,N,0,0,0);

	cout<<"THE MAXIMUM SCORE COLLECTED IS "<<max<<endl;
	for(int i=0;i<2;i++)
	{
			delete [] matrix[i];
	}
	delete [] matrix;
}
