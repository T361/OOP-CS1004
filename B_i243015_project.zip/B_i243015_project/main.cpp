#include <iostream>
#include <string>
#include <math.h>
#include <SFML/Graphics.hpp>
#include <ctime>
#include <SFML/Audio.hpp>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;
using namespace sf;
// Taimoor Shaukat , SE-B , 24i-3015 , OOP  Final Project
// abstract pet class as its obj wont be made
class pet
{
protected:
    int petid;
    int health;
    int attack;
    int sped;
    int def;
    int exp;
    string name;

public:
    virtual int getid() = 0;
    virtual int gethealth() = 0;
    virtual int getattack() = 0;
    virtual int getdef() = 0;
    virtual string getname() = 0;
    virtual int getexp() = 0;
    virtual int getsped() = 0;
    virtual void setid(int id) = 0;
    virtual void sethealth(int h) = 0;
    virtual void setattack(int a) = 0;
    virtual void setdef(int d) = 0;
    virtual void setname(string n) = 0;
    virtual void setexp(int e) = 0;
    virtual void setsped(int s) = 0;
};
// dragon class
class dragon : public pet
{
private:
    int fireball = 120;
    int dragonsroar = 0;

public:
    int getid()
    {
        return petid;
    }
    int gethealth()
    {
        return health;
    }
    int getattack()
    {
        return attack;
    }
    int getdef()
    {
        return def;
    }
    string getname()
    {
        return name;
    }
    int getexp()
    {
        return exp;
    }
    int getsped()
    {
        return sped;
    }
    void setid(int id)
    {
        petid = id;
    }
    void sethealth(int h)
    {
        health = h;
    }
    void setattack(int a)
    {
        attack = a;
    }
    void setdef(int d)
    {
        def = d;
    }
    void setname(string n)
    {
        name = n;
    }
    void setexp(int e)
    {
        exp = e;
    }
    void setsped(int s)
    {
        sped = s;
    }
    // ability functions
    void ability1(int &enemyhealth)
    {
        enemyhealth -= fireball;
    }
    void ability2()
    {
        sped = sped + 0.1;
    }
    dragon()
    {
        petid = 1;
        health = 200;
        attack = 100;
        def = 10;
        sped = 50;
        exp = 0;
        name = "Dragon";
    }
};
// unicorn class
class unicorn : public pet
{
private:
    int speedburst = 120;
    int shield = 0;

public:
    int getid()
    {
        return petid;
    }
    int gethealth()
    {
        return health;
    }
    int getattack()
    {
        return attack;
    }
    int getdef()
    {
        return def;
    }
    string getname()
    {
        return name;
    }
    int getexp()
    {
        return exp;
    }
    int getsped()
    {
        return sped;
    }
    void setid(int id)
    {
        petid = id;
    }
    void sethealth(int h)
    {
        health = h;
    }
    void setattack(int a)
    {
        attack = a;
    }
    void setdef(int d)
    {
        def = d;
    }
    void setname(string n)
    {
        name = n;
    }
    void setexp(int e)
    {
        exp = e;
    }
    void setsped(int s)
    {
        sped = s;
    }
    // ability functions
    void ability1()
    {
        sped += speedburst;
    }
    void ability2()
    {
        def = def + 1;
    }
    unicorn()
    {
        petid = 2;
        health = 40;
        attack = 70;
        def = 10;
        sped = 100;
        exp = 0;
        name = "Unicorn";
    }
};
// griffin class
class griffin : public pet
{
private:
    int clawstrike = 100;
    int divebomb = 0;

public:
    int getid()
    {
        return petid;
    }
    int gethealth()
    {
        return health;
    }
    int getattack()
    {
        return attack;
    }
    int getdef()
    {
        return def;
    }
    string getname()
    {
        return name;
    }
    int getexp()
    {
        return exp;
    }
    int getsped()
    {
        return sped;
    }
    void setid(int id)
    {
        petid = id;
    }
    void sethealth(int h)
    {
        health = h;
    }
    void setattack(int a)
    {
        attack = a;
    }
    void setdef(int d)
    {
        def = d;
    }
    void setname(string n)
    {
        name = n;
    }
    void setexp(int e)
    {
        exp = e;
    }
    void setsped(int s)
    {
        sped = s;
    }
    // ability functions
    void ability1(int &enemyhealth)
    {
        enemyhealth -= clawstrike;
    }
    void ability2()
    {
        sped = sped + 0.1;
    }
    griffin()
    {
        petid = 3;
        health = 80;
        attack = 80;
        def = 50;
        sped = 80;
        exp = 0;
        name = "Griffin";
    }
};
// phoenix class
class phoenix : public pet
{
private:
    int flameheal = 100;
    int rebirth = 0;

public:
    int getid()
    {
        return petid;
    }
    int gethealth()
    {
        return health;
    }
    int getattack()
    {
        return attack;
    }
    int getdef()
    {
        return def;
    }
    string getname()
    {
        return name;
    }
    int getexp()
    {
        return exp;
    }
    int getsped()
    {
        return sped;
    }
    void setid(int id)
    {
        petid = id;
    }
    void sethealth(int h)
    {
        health = h;
    }
    void setattack(int a)
    {
        attack = a;
    }
    void setdef(int d)
    {
        def = d;
    }
    void setname(string n)
    {
        name = n;
    }
    void setexp(int e)
    {
        exp = e;
    }
    void setsped(int s)
    {
        sped = s;
    }
    // ability functions
    void ability1()
    {
        health += flameheal;
    }
    void ability2()
    {
        health = health + 130;
    }
    phoenix()
    {
        petid = 4;
        health = 70;
        attack = 50;
        def = 200;
        sped = 20;
        exp = 0;
        name = "Phoenix";
    }
};
// player class
class player
{
    string name;
    int id;
    int coins;
    phoenix p;
    dragon d;
    griffin g;
    unicorn u;
    int noofheals = 0;
    int noofbuffs = 0;
    int noofmana = 0;
    int noofshields = 0;

public:
    phoenix &getphoenix()
    {
        return p;
    }
    dragon &getdragon()
    {
        return d;
    }
    griffin &getgriffin()
    {
        return g;
    }
    unicorn &getunicorn()
    {
        return u;
    }
    void setname(string n)
    {
        name = n;
    }
    void setid(int i)
    {
        id = i;
    }
    void setcoins(int c)
    {
        coins = c;
    }
    void setnoofheals(int h)
    {
        noofheals = h;
    }
    void setnoofbuffs(int b)
    {
        noofbuffs = b;
    }
    void setnoofmana(int m)
    {
        noofmana = m;
    }
    void setnoofshields(int s)
    {
        noofshields = s;
    }
    string getname()
    {
        return name;
    }
    int getid()
    {
        return id;
    }
    int getcoins()
    {
        return coins;
    }
    int getnoofheals()
    {
        return noofheals;
    }
    int getnoofbuffs()
    {
        return noofbuffs;
    }
    int getnoofmana()
    {
        return noofmana;
    }
    int getnoofshields()
    {
        return noofshields;
    }
    player()
    {
        name = "Player";
        id = 0;
        coins = 0;
        noofheals = 0;
        noofbuffs = 0;
        noofmana = 0;
        noofshields = 0;
    }
    void operator()()
    {
        // saving coins to file by overwriting
        ofstream file("playercoins.txt", ios::out);
        if (!file.is_open())
        {
            cout << "Failed to open file ";
            return;
        }
        file << getcoins() << endl;
        file.close();
    }

    void storeotherdata()
    {
        // saving items to file by overwriting
        ofstream file("playeritems.txt", ios::out);
        if (!file.is_open())
        {
            cout << "Failed to open file ";
            return;
        }
        file << getnoofbuffs() << endl;
        file << getnoofheals() << endl;
        file << getnoofmana() << endl;
        file << getnoofshields() << endl;
        file.close();
    }

    void storepetdata()
    {
        // saving pet stats to file by overwriting
        ofstream file("playerpetstats.txt", ios::out);
        if (!file.is_open())
        {
            cout << "Failed to open file ";
            return;
        }

        file << getgriffin().getname() << endl;
        file << getgriffin().getattack() << endl;
        file << getgriffin().getdef() << endl;
        file << getgriffin().getsped() << endl;
        file << getgriffin().gethealth() << endl;
        file << getgriffin().getexp() << endl;

        file << getdragon().getname() << endl;
        file << getdragon().getattack() << endl;
        file << getdragon().getdef() << endl;
        file << getdragon().getsped() << endl;
        file << getdragon().gethealth() << endl;
        file << getdragon().getexp() << endl;

        file << getphoenix().getname() << endl;
        file << getphoenix().getattack() << endl;
        file << getphoenix().getdef() << endl;
        file << getphoenix().getsped() << endl;
        file << getphoenix().gethealth() << endl;
        file << getphoenix().getexp() << endl;

        file << getunicorn().getname() << endl;
        file << getunicorn().getattack() << endl;
        file << getunicorn().getdef() << endl;
        file << getunicorn().getsped() << endl;
        file << getunicorn().gethealth() << endl;
        file << getunicorn().getexp() << endl;

        file.close();
    }

    // function to load data from file
    // loading previous saved coins
    void loadData()
    {
        ifstream file("playercoins.txt");
        if (!file.is_open())
        {
            cout << "Failed to open file ";
            return;
        }
        int coins;
        while (file >> coins)
        {
            setcoins(coins);
        }
        file.close();
    }
    // loading previous saved items
    void loadotherdata()
    {
        ifstream file("playeritems.txt");
        if (!file.is_open())
        {
            cout << "Failed to open file ";
            return;
        }
        int buff, heal, mana, shield;
        while (file >> buff >> heal >> mana >> shield)
        {
            setnoofbuffs(buff);
            setnoofheals(heal);
            setnoofmana(mana);
            setnoofshields(shield);
        }
        file.close();
    }
    // loading previous saved pet stats
    void loadpetdata()
    {
        ifstream file("playerpetstats.txt");
        if (!file.is_open())
        {
            cout << "Failed to open file ";
            return;
        }
        string name;
        int attack, def, sped, health, exp;

        while (file >> name >> attack >> def >> sped >> health >> exp)
        {
            getgriffin().setname(name);
            getgriffin().setattack(attack);
            getgriffin().setdef(def);
            getgriffin().setsped(sped);
            getgriffin().sethealth(health);
            getgriffin().setexp(exp);

            file >> name >> attack >> def >> sped >> health >> exp;
            getdragon().setname(name);
            getdragon().setattack(attack);
            getdragon().setdef(def);
            getdragon().setsped(sped);
            getdragon().sethealth(health);
            getdragon().setexp(exp);

            file >> name >> attack >> def >> sped >> health >> exp;
            getphoenix().setname(name);
            getphoenix().setattack(attack);
            getphoenix().setdef(def);
            getphoenix().setsped(sped);
            getphoenix().sethealth(health);
            getphoenix().setexp(exp);

            file >> name >> attack >> def >> sped >> health >> exp;
            getunicorn().setname(name);
            getunicorn().setattack(attack);
            getunicorn().setdef(def);
            getunicorn().setsped(sped);
            getunicorn().sethealth(health);
            getunicorn().setexp(exp);
        }
        file.close();
    }
};
// each func to train each pet and increase their stats through getters and setters
void photrain(phoenix &p)
{
    Music music;
    if (!music.openFromFile("phoenix.ogg"))
    {
        cout << "e";
    }
    music.setLoop(true);
    music.setVolume(200.f);
    music.play();
    RenderWindow window(VideoMode(1018, 573), "TRAIN YOUR PHOENIX OR CROSS OUT TO EXIT TRAINING");
    Texture nest;
    if (!nest.loadFromFile("phoenixnest.png"))
    {
        cout << "er";
    }
    Sprite bg;
    bg.setTexture(nest);
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
            {
                window.close();
            }
        }
        if (Keyboard::isKeyPressed(Keyboard::P))
        {
            p.setexp(p.getexp() + 10);
        }
        if (Keyboard::isKeyPressed(Keyboard::H))
        {
            p.sethealth(p.gethealth() + p.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::A))
        {
            p.setattack(p.getattack() + p.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::S))
        {
            p.setsped(p.getsped() + p.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::D))
        {
            p.setdef(p.getdef() + p.getexp());
        }
        window.clear();
        window.draw(bg);
        window.display();
    }
}
void unitrain(unicorn &u)
{
    Music music;
    if (!music.openFromFile("unicorn.ogg"))
    {
        cout << "e";
    }
    music.setLoop(true);
    music.setVolume(200.f);
    music.play();
    RenderWindow window(VideoMode(1018, 573), "TRAIN YOUR UNICORN OR CROSS OUT TO EXIT TRAINING");
    Texture nest;
    if (!nest.loadFromFile("unicornnest.png"))
    {
        cout << "er";
    }
    Sprite bg;
    bg.setTexture(nest);
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {

            if (event.type == Event::Closed)
            {
                window.close();
            }
        }
        if (Keyboard::isKeyPressed(Keyboard::U))
        {
            u.setexp(u.getexp() + 10);
        }
        if (Keyboard::isKeyPressed(Keyboard::H))
        {
            u.sethealth(u.gethealth() + u.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::A))
        {
            u.setattack(u.getattack() + u.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::S))
        {
            u.setsped(u.getsped() + u.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::D))
        {
            u.setdef(u.getdef() + u.getexp());
        }

        window.clear();
        window.draw(bg);
        window.display();
    }
}
void dratrain(dragon &d)
{
    Music music;
    if (!music.openFromFile("dragon.ogg"))
    {
        cout << "e";
    }
    music.setLoop(true);
    music.setVolume(200.f);
    music.play();
    RenderWindow window(VideoMode(1018, 573), "TRAIN YOUR DRAGON OR CROSS OUT TO EXIT TRAINING");
    Texture nest;
    if (!nest.loadFromFile("dragonnest.png"))
    {
        cout << "er";
    }
    Sprite bg;
    bg.setTexture(nest);
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {

            if (event.type == Event::Closed)
            {
                window.close();
            }
        }
        if (Keyboard::isKeyPressed(Keyboard::D))
        {
            d.setexp(d.getexp() + 10);
        }
        if (Keyboard::isKeyPressed(Keyboard::H))
        {
            d.sethealth(d.gethealth() + d.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::A))
        {
            d.setattack(d.getattack() + d.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::S))
        {
            d.setsped(d.getsped() + d.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::E))
        {
            d.setdef(d.getdef() + d.getexp());
        }

        window.clear();
        window.draw(bg);
        window.display();
    }
}
void griftrain(griffin &g)
{
    Music music;
    if (!music.openFromFile("griffin.ogg"))
    {
        cout << "e";
    }
    music.setLoop(true);
    music.setVolume(200.f);
    music.play();
    RenderWindow window(VideoMode(1018, 573), "TRAIN YOUR GRIFFIN OR CROSS OUT TO EXIT TRAINING");
    Texture nest;
    if (!nest.loadFromFile("grifnest.png"))
    {
        cout << "er";
    }
    Sprite bg;
    bg.setTexture(nest);
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            // Close the window when the user clicks the close button
            if (event.type == Event::Closed)
            {
                window.close();
            }
        }
        if (Keyboard::isKeyPressed(Keyboard::G))
        {
            g.setexp(g.getexp() + 10);
        }
        if (Keyboard::isKeyPressed(Keyboard::H))
        {
            g.sethealth(g.gethealth() + g.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::A))
        {
            g.setattack(g.getattack() + g.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::S))
        {
            g.setsped(g.getsped() + g.getexp());
        }
        if (Keyboard::isKeyPressed(Keyboard::D))
        {
            g.setdef(g.getdef() + g.getexp());
        }
        window.clear();
        window.draw(bg);
        window.display();
    }
}
// training camp class
class trainingcamp
{

public:
    // function for training
    void trainpet(player &p)
    {
        RenderWindow window(sf::VideoMode(1018, 573), "Which Pet to train,or cross out to exit ");
        Texture dojo;
        if (!dojo.loadFromFile("dojo.png"))
        {
            cout << "eror";
        }
        Sprite bg;
        bg.setTexture(dojo);
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {
                if (event.type == sf::Event::Closed)
                {
                    window.close();
                }
            } 
            // individual functions for training
            if (Keyboard::isKeyPressed(Keyboard::G))
            {
                griftrain(p.getgriffin());
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                unitrain(p.getunicorn());
            }
            if (Keyboard::isKeyPressed(Keyboard::P))
            {
                photrain(p.getphoenix());
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                dratrain(p.getdragon());
            }
            window.clear();
            window.draw(bg);
            window.display();
        }
    }
};
class shop
{
private:
    int priceofbuff = 10;
    int priceofmana = 10;
    int priceofheal = 10;
    int priceofshield = 10;

public:
    // getters
    int getbuff() const
    {
        return priceofbuff;
    }
    int getmana() const
    {
        return priceofmana;
    }
    int getheal() const
    {
        return priceofheal;
    }
    int getshield() const
    {
        return priceofshield;
    }
    void buyitem(player &p)
    {
        RenderWindow window(sf::VideoMode(1018, 573), "SHOP , CROSS OUT TO EXIT ");
        Texture bg3, errorimage;
        if (!bg3.loadFromFile("bg2.png"))
        {
            cout << "unavailable" << endl;
        }
        if (!errorimage.loadFromFile("error.png"))
        {
            cout << "eror";
        }

        Sprite backgroundSprite;
        backgroundSprite.setTexture(bg3);

        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {
                if (event.type == Event::Closed)
                {
                    window.close();
                }
                // checks if coins available then buys product and if not enough coins then displays insufficient coins image
                if (event.type == Event::KeyPressed)
                {
                    int coins = p.getcoins();

                    if (event.key.code == Keyboard::B)
                    {
                        int cost = getbuff();
                        if (coins >= cost)
                        {
                            p.setnoofbuffs(p.getnoofbuffs() + 1);
                            p.setcoins(coins - cost);
                            backgroundSprite.setTexture(bg3); // reset background to normal
                        }
                        else
                        {
                            backgroundSprite.setTexture(errorimage);
                        }
                    }
                    else if (event.key.code == Keyboard::M)
                    {
                        int cost = getmana();
                        if (coins >= cost)
                        {
                            p.setnoofmana(p.getnoofmana() + 1);
                            p.setcoins(coins - cost);
                            backgroundSprite.setTexture(bg3);
                        }
                        else
                        {
                            backgroundSprite.setTexture(errorimage);
                        }
                    }
                    else if (event.key.code == Keyboard::H)
                    {
                        int cost = getheal();
                        if (coins >= cost)
                        {
                            p.setnoofheals(p.getnoofheals() + 1);
                            p.setcoins(coins - cost);
                            backgroundSprite.setTexture(bg3);
                        }
                        else
                        {
                            backgroundSprite.setTexture(errorimage);
                        }
                    }
                    else if (event.key.code == Keyboard::S)
                    {
                        int cost = getshield();
                        if (coins >= cost)
                        {
                            p.setnoofshields(p.getnoofshields() + 1);
                            p.setcoins(coins - cost);
                            backgroundSprite.setTexture(bg3);
                        }
                        else
                        {
                            backgroundSprite.setTexture(errorimage);
                        }
                    }
                }
            }

            window.clear();
            window.draw(backgroundSprite);
            window.display();
        }
    }
};
// arena class
class arena1v1
{
public:
    void dragonbattle(dragon d, player &p)
    {
        Texture playerProjectileTexture;
        playerProjectileTexture.loadFromFile("fireball.png");

        Texture enemyProjectileTexture;
        enemyProjectileTexture.loadFromFile("efireball.png");

        srand(time(0));
        int num = rand() % 4;
        int enemyhealth = 2000; // Enemy health fixed
        int og = d.gethealth();
        RenderWindow window(VideoMode(1018, 573), "BATTLE ARENA");
        RectangleShape obstacle(Vector2f(101.f, 229.f)); // width & height
        obstacle.setPosition(507.f, 400.f);
        Texture bg;
        bg.loadFromFile("battle1.png");
        Sprite backgroundSprite(bg);

        Texture playerTexture;
        playerTexture.loadFromFile("dra.png");
        Sprite playerSprite(playerTexture);
        playerSprite.setScale(0.5f, 0.5f);
        playerSprite.setPosition(100, 100);

        // Enemy
        // random enemy spirite
        Texture enemyTexture;
        if (num == 0)
        {
            enemyTexture.loadFromFile("dra.png");
        }
        else if (num == 1)
        {
            enemyTexture.loadFromFile("pho.png");
        }
        else if (num == 2)
        {
            enemyTexture.loadFromFile("uni.png");
        }
        else if (num == 3)
        {
            enemyTexture.loadFromFile("g.png");
        }
        Sprite enemySprite(enemyTexture);
        enemySprite.setScale(0.5f, 0.5f);
        enemySprite.setPosition(800, 100);

        float dragonspeed = d.getsped();
        float speed = 0.01f * dragonspeed;
        float projSpeed = 1.5f;

        const int maxProjectiles = 100;
        Sprite playerProjectiles[maxProjectiles];
        Sprite enemyProjectiles[maxProjectiles];
        bool playerActive[maxProjectiles] = {};
        bool enemyActive[maxProjectiles] = {};
        float playerX[maxProjectiles], playerY[maxProjectiles];
        float enemyX[maxProjectiles], enemyY[maxProjectiles];

        // Initialize the projectiles
        for (int i = 0; i < maxProjectiles; i++)
        {
            playerProjectiles[i].setTexture(playerProjectileTexture);
            playerProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
            enemyProjectiles[i].setTexture(enemyProjectileTexture);
            enemyProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
        }

        int playerIndex = 0;
        int enemyIndex = 0;

        Clock fireClock;
        Clock enemyFireClock;
        Clock enemyMoveClock;

        float enemyDir = 1.0f;
        FloatRect potionBounds(507.f, 150.f, 50.f, 50.f);

        FloatRect nextPos = playerSprite.getGlobalBounds();
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {
                if (event.type == Event::Closed)
                {
                    window.close();
                }
            }

            // Movement for player's pet
            FloatRect obstacleBounds = obstacle.getGlobalBounds();
            FloatRect currentBounds = playerSprite.getGlobalBounds();

            if (Keyboard::isKeyPressed(Keyboard::Up))
            {
                FloatRect next = currentBounds;
                next.top -= speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(0, -speed);
                }
            }

            if (Keyboard::isKeyPressed(Keyboard::Down))
            {
                FloatRect next = currentBounds;
                next.top += speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(0, speed);
                }
            }

            if (Keyboard::isKeyPressed(Keyboard::Left))
            {
                FloatRect next = currentBounds;
                next.left -= speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(-speed, 0);
                }
            }

            if (Keyboard::isKeyPressed(Keyboard::Right))
            {
                FloatRect next = currentBounds;
                next.left += speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(speed, 0);
                }
            }

            // Player fire
            if (Keyboard::isKeyPressed(Keyboard::Space) && fireClock.getElapsedTime().asMilliseconds() > 200)
            {
                playerX[playerIndex] = playerSprite.getPosition().x + 50;
                playerY[playerIndex] = playerSprite.getPosition().y + 25;
                playerProjectiles[playerIndex].setPosition(playerX[playerIndex], playerY[playerIndex]);
                playerActive[playerIndex] = true;
                playerIndex = (playerIndex + 1) % maxProjectiles;
                fireClock.restart();
            }
            if (Keyboard::isKeyPressed(Keyboard::Y))
            {
                d.ability1(enemyhealth);
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                d.ability2();
            }
            if (Keyboard::isKeyPressed(Keyboard::M) && p.getnoofmana() > 0)
            {
                d.sethealth(d.gethealth() + p.getnoofmana());
                p.setnoofmana(p.getnoofmana() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::H) && p.getnoofheals() > 0)
            {
                d.sethealth(d.gethealth() + p.getnoofheals());
                p.setnoofheals(p.getnoofheals() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::S) && p.getnoofshields() > 0)
            {
                d.setdef(d.getdef() + p.getnoofshields());
                p.setnoofshields(p.getnoofshields() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::B) && p.getnoofbuffs() > 0)
            {
                d.setattack(d.getattack() + p.getnoofbuffs());
                p.setnoofbuffs(p.getnoofbuffs() - 1);
            }
            // Enemy oscillation movement
            if (enemyMoveClock.getElapsedTime().asMilliseconds() > 10)
            {
                enemySprite.move(0, 0.5f * enemyDir);
                if (enemySprite.getPosition().y < 0 || enemySprite.getPosition().y > 500)
                {
                    enemyDir *= -1;
                }
                enemyMoveClock.restart();
            }

            // Enemy fire
            if (enemyFireClock.getElapsedTime().asMilliseconds() > 400)
            {
                enemyX[enemyIndex] = enemySprite.getPosition().x - 10;
                enemyY[enemyIndex] = enemySprite.getPosition().y + 25;
                enemyProjectiles[enemyIndex].setPosition(enemyX[enemyIndex], enemyY[enemyIndex]);
                enemyActive[enemyIndex] = true;
                enemyIndex = (enemyIndex + 1) % maxProjectiles;
                enemyFireClock.restart();
            }

            // Move projectiles
            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                {
                    playerX[i] += projSpeed;
                    playerProjectiles[i].setPosition(playerX[i], playerY[i]);
                    if (playerX[i] > 1018)
                        playerActive[i] = false;
                }
                if (enemyActive[i])
                {
                    enemyX[i] -= projSpeed;
                    enemyProjectiles[i].setPosition(enemyX[i], enemyY[i]);
                    if (enemyX[i] < 0)
                        enemyActive[i] = false;
                }
            }

            // Check for collisions with enemy
            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i] && playerProjectiles[i].getGlobalBounds().intersects(enemySprite.getGlobalBounds()))
                {
                    enemyhealth -= (10 + d.getattack() * 0.5); // Subtract health from the enemy
                    playerActive[i] = false;
                }

                // Check if enemy projectiles hit the player's dragon
                if (enemyActive[i] && enemyProjectiles[i].getGlobalBounds().intersects(playerSprite.getGlobalBounds()))
                {
                    d.sethealth(d.gethealth() - (100 - (d.getdef() * 0.5))); // Subtract health from the player's dragon
                    enemyActive[i] = false;
                }
            }
            if (playerSprite.getGlobalBounds().intersects(potionBounds))
            {
                int boostType = rand() % 3;
                if (boostType == 0)
                {
                    d.setattack(d.getattack() + 0.25);
                }
                else if (boostType == 1)
                {
                    d.setdef(d.getdef() + 0.25);
                }
                else
                {
                    d.setsped(d.getsped() + 0.25);
                }
            }

            // Win or Lose condition
            if (enemyhealth <= 0)
            {
                p.setcoins(p.getcoins() + 10); // Player gets +10 coins
                Texture winTex;
                winTex.loadFromFile("win.png");
                Sprite winSprite(winTex);
                window.clear();
                window.draw(winSprite);
                window.display();
                sleep(seconds(3));
                window.close();
                return;
            }

            if (d.gethealth() <= 0)
            {
                Texture loseTex;
                loseTex.loadFromFile("lose.png");
                Sprite loseSprite(loseTex);
                window.clear();
                window.draw(loseSprite);
                window.display();
                sleep(seconds(3));
                // Reset player's pets health
                d.sethealth(og);
                window.close();
                return;
            }

            window.clear();
            window.draw(backgroundSprite);
            window.draw(playerSprite);
            window.draw(enemySprite);

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                    window.draw(playerProjectiles[i]);
                if (enemyActive[i])
                    window.draw(enemyProjectiles[i]);
            }

            window.display();
        }
    }
    void phoenixbattle(phoenix ph, player &p)
    {
        srand(time(0));
        int num = rand() % 4;
        int enemyhealth = 2000;
        int og = ph.gethealth();
        Texture playerProjectileTexture;
        playerProjectileTexture.loadFromFile("fireball.png");

        Texture enemyProjectileTexture;
        enemyProjectileTexture.loadFromFile("efireball.png");

        RenderWindow window(VideoMode(1018, 573), "BATTLE ARENA");
        RectangleShape obstacle(Vector2f(101.f, 229.f));
        obstacle.setPosition(507.f, 400.f);

        Texture bg;
        bg.loadFromFile("battle1.png");
        Sprite backgroundSprite(bg);

        Texture playerTexture;
        playerTexture.loadFromFile("pho.png"); // Phoenix texture
        Sprite playerSprite(playerTexture);
        playerSprite.setScale(0.5f, 0.5f);
        playerSprite.setPosition(100, 100);

        Texture enemyTexture;
        if (num == 0)
            enemyTexture.loadFromFile("dra.png");
        else if (num == 1)
            enemyTexture.loadFromFile("pho.png");
        else if (num == 2)
            enemyTexture.loadFromFile("uni.png");
        else
            enemyTexture.loadFromFile("g.png");

        Sprite enemySprite(enemyTexture);
        enemySprite.setScale(0.5f, 0.5f);
        enemySprite.setPosition(800, 100);

        float phoenixspeed = ph.getsped();
        float speed = 0.01f * phoenixspeed;
        float projSpeed = 1.5f;

        const int maxProjectiles = 100;
        Sprite playerProjectiles[maxProjectiles];
        Sprite enemyProjectiles[maxProjectiles];
        bool playerActive[maxProjectiles] = {};
        bool enemyActive[maxProjectiles] = {};
        float playerX[maxProjectiles], playerY[maxProjectiles];
        float enemyX[maxProjectiles], enemyY[maxProjectiles];

        // Initialize the projectiles
        for (int i = 0; i < maxProjectiles; i++)
        {
            playerProjectiles[i].setTexture(playerProjectileTexture);
            playerProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
            enemyProjectiles[i].setTexture(enemyProjectileTexture);
            enemyProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
        }

        int playerIndex = 0, enemyIndex = 0;

        Clock fireClock, enemyFireClock, enemyMoveClock;
        float enemyDir = 1.0f;
        FloatRect potionBounds(507.f, 150.f, 50.f, 50.f);

        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {
                if (event.type == Event::Closed)
                    window.close();
            }

            FloatRect obstacleBounds = obstacle.getGlobalBounds();
            FloatRect currentBounds = playerSprite.getGlobalBounds();

            if (Keyboard::isKeyPressed(Keyboard::Up))
            {
                FloatRect next = currentBounds;
                next.top -= speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(0, -speed);
            }
            if (Keyboard::isKeyPressed(Keyboard::Down))
            {
                FloatRect next = currentBounds;
                next.top += speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(0, speed);
            }
            if (Keyboard::isKeyPressed(Keyboard::Left))
            {
                FloatRect next = currentBounds;
                next.left -= speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(-speed, 0);
            }
            if (Keyboard::isKeyPressed(Keyboard::Right))
            {
                FloatRect next = currentBounds;
                next.left += speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(speed, 0);
            }

            if (Keyboard::isKeyPressed(Keyboard::Space) && fireClock.getElapsedTime().asMilliseconds() > 200)
            {
                playerX[playerIndex] = playerSprite.getPosition().x + 50;
                playerY[playerIndex] = playerSprite.getPosition().y + 25;
                playerProjectiles[playerIndex].setPosition(playerX[playerIndex], playerY[playerIndex]);
                playerActive[playerIndex] = true;
                playerIndex = (playerIndex + 1) % maxProjectiles;
                fireClock.restart();
            }
            if (Keyboard::isKeyPressed(Keyboard::Y))
            {
                ph.ability1();
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                ph.ability2();
            }
            if (Keyboard::isKeyPressed(Keyboard::M) && p.getnoofmana() > 0)
            {
                ph.sethealth(ph.gethealth() + p.getnoofmana());
                p.setnoofmana(p.getnoofmana() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::H) && p.getnoofheals() > 0)
            {
                ph.sethealth(ph.gethealth() + p.getnoofheals());
                p.setnoofheals(p.getnoofheals() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::S) && p.getnoofshields() > 0)
            {
                ph.setdef(ph.getdef() + p.getnoofshields());
                p.setnoofshields(p.getnoofshields() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::B) && p.getnoofbuffs() > 0)
            {
                ph.setattack(ph.getattack() + p.getnoofbuffs());
                p.setnoofbuffs(p.getnoofbuffs() - 1);
            }
            if (enemyMoveClock.getElapsedTime().asMilliseconds() > 10)
            {
                enemySprite.move(0, 0.5f * enemyDir);
                if (enemySprite.getPosition().y < 0 || enemySprite.getPosition().y > 500)
                    enemyDir *= -1;
                enemyMoveClock.restart();
            }

            if (enemyFireClock.getElapsedTime().asMilliseconds() > 400)
            {
                enemyX[enemyIndex] = enemySprite.getPosition().x - 10;
                enemyY[enemyIndex] = enemySprite.getPosition().y + 25;
                enemyProjectiles[enemyIndex].setPosition(enemyX[enemyIndex], enemyY[enemyIndex]);
                enemyActive[enemyIndex] = true;
                enemyIndex = (enemyIndex + 1) % maxProjectiles;
                enemyFireClock.restart();
            }
            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                {
                    playerX[i] += projSpeed;
                    playerProjectiles[i].setPosition(playerX[i], playerY[i]);
                    if (playerX[i] > 1018)
                        playerActive[i] = false;
                }
                if (enemyActive[i])
                {
                    enemyX[i] -= projSpeed;
                    enemyProjectiles[i].setPosition(enemyX[i], enemyY[i]);
                    if (enemyX[i] < 0)
                        enemyActive[i] = false;
                }
            }

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i] && playerProjectiles[i].getGlobalBounds().intersects(enemySprite.getGlobalBounds()))
                {
                    enemyhealth -= (10 + ph.getattack() * 0.5);
                    playerActive[i] = false;
                }
                if (enemyActive[i] && enemyProjectiles[i].getGlobalBounds().intersects(playerSprite.getGlobalBounds()))
                {
                    ph.sethealth(ph.gethealth() - (100 - (ph.getdef() * 0.5)));
                    enemyActive[i] = false;
                }
            }

            if (playerSprite.getGlobalBounds().intersects(potionBounds))
            {
                int boostType = rand() % 3;
                if (boostType == 0)
                    ph.setattack(ph.getattack() + 0.25);
                else if (boostType == 1)
                    ph.setdef(ph.getdef() + 0.25);
                else
                    ph.setsped(ph.getsped() + 0.25);
            }

            if (enemyhealth <= 0)
            {
                p.setcoins(p.getcoins() + 10);
                Texture winTex;
                winTex.loadFromFile("win.png");
                Sprite winSprite(winTex);
                window.clear();
                window.draw(winSprite);
                window.display();
                sleep(seconds(3));
                window.close();
                return;
            }

            if (ph.gethealth() <= 0)
            {
                Texture loseTex;
                loseTex.loadFromFile("lose.png");
                Sprite loseSprite(loseTex);
                window.clear();
                window.draw(loseSprite);
                window.display();
                sleep(seconds(3));
                ph.sethealth(og);
                window.close();
                return;
            }

            window.clear();
            window.draw(backgroundSprite);
            window.draw(playerSprite);
            window.draw(enemySprite);
            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                    window.draw(playerProjectiles[i]);
                if (enemyActive[i])
                    window.draw(enemyProjectiles[i]);
            }
            window.display();
        }
    }

    void griffinbattle(griffin &g, player &p)
    {
        Texture playerProjectileTexture;
        playerProjectileTexture.loadFromFile("fireball.png");

        Texture enemyProjectileTexture;
        enemyProjectileTexture.loadFromFile("efireball.png");

        srand(time(0));
        int num = rand() % 4;
        int enemyhealth = 2000; // Enemy health fixed
        int og = g.gethealth();
        RenderWindow window(VideoMode(1018, 573), "BATTLE ARENA");
        RectangleShape obstacle(Vector2f(101.f, 229.f));
        obstacle.setPosition(507.f, 400.f);
        Texture bg;
        bg.loadFromFile("battle1.png");
        Sprite backgroundSprite(bg);

        Texture playerTexture;
        playerTexture.loadFromFile("g.png"); // griffin sprite
        Sprite playerSprite(playerTexture);
        playerSprite.setScale(0.5f, 0.5f);
        playerSprite.setPosition(100, 100);

        Texture enemyTexture;
        if (num == 0)
            enemyTexture.loadFromFile("dra.png");
        else if (num == 1)
            enemyTexture.loadFromFile("pho.png");
        else if (num == 2)
            enemyTexture.loadFromFile("uni.png");
        else
            enemyTexture.loadFromFile("g.png");

        Sprite enemySprite(enemyTexture);
        enemySprite.setScale(0.5f, 0.5f);
        enemySprite.setPosition(800, 100);

        float griffinspeed = g.getsped();
        float speed = 0.01f * griffinspeed;
        float projSpeed = 1.5f;

        const int maxProjectiles = 100;
        Sprite playerProjectiles[maxProjectiles];
        Sprite enemyProjectiles[maxProjectiles];
        bool playerActive[maxProjectiles] = {};
        bool enemyActive[maxProjectiles] = {};
        float playerX[maxProjectiles], playerY[maxProjectiles];
        float enemyX[maxProjectiles], enemyY[maxProjectiles];

        // Initialize the projectiles
        for (int i = 0; i < maxProjectiles; i++)
        {
            playerProjectiles[i].setTexture(playerProjectileTexture);
            playerProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
            enemyProjectiles[i].setTexture(enemyProjectileTexture);
            enemyProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
        }

        int playerIndex = 0;
        int enemyIndex = 0;

        Clock fireClock, enemyFireClock, enemyMoveClock;
        float enemyDir = 1.0f;
        FloatRect potionBounds(507.f, 150.f, 50.f, 50.f);

        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {
                if (event.type == Event::Closed)
                    window.close();
            }

            FloatRect obstacleBounds = obstacle.getGlobalBounds();
            FloatRect currentBounds = playerSprite.getGlobalBounds();

            if (Keyboard::isKeyPressed(Keyboard::Up))
            {
                FloatRect next = currentBounds;
                next.top -= speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(0, -speed);
            }
            if (Keyboard::isKeyPressed(Keyboard::Down))
            {
                FloatRect next = currentBounds;
                next.top += speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(0, speed);
            }
            if (Keyboard::isKeyPressed(Keyboard::Left))
            {
                FloatRect next = currentBounds;
                next.left -= speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(-speed, 0);
            }
            if (Keyboard::isKeyPressed(Keyboard::Right))
            {
                FloatRect next = currentBounds;
                next.left += speed;
                if (!next.intersects(obstacleBounds))
                    playerSprite.move(speed, 0);
            }
            if (Keyboard::isKeyPressed(Keyboard::Y))
            {
                g.ability1(enemyhealth);
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                g.ability2();
            }
            if (Keyboard::isKeyPressed(Keyboard::M) && p.getnoofmana() > 0)
            {
                g.sethealth(g.gethealth() + p.getnoofmana());
                p.setnoofmana(p.getnoofmana() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::H) && p.getnoofheals() > 0)
            {
                g.sethealth(g.gethealth() + p.getnoofheals());
                p.setnoofheals(p.getnoofheals() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::S) && p.getnoofshields() > 0)
            {
                g.setdef(g.getdef() + p.getnoofshields());
                p.setnoofshields(p.getnoofshields() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::B) && p.getnoofbuffs() > 0)
            {
                g.setattack(g.getattack() + p.getnoofbuffs());
                p.setnoofbuffs(p.getnoofbuffs() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::Space) && fireClock.getElapsedTime().asMilliseconds() > 200)
            {
                playerX[playerIndex] = playerSprite.getPosition().x + 50;
                playerY[playerIndex] = playerSprite.getPosition().y + 25;
                playerProjectiles[playerIndex].setPosition(playerX[playerIndex], playerY[playerIndex]);
                playerActive[playerIndex] = true;
                playerIndex = (playerIndex + 1) % maxProjectiles;
                fireClock.restart();
            }

            if (enemyMoveClock.getElapsedTime().asMilliseconds() > 10)
            {
                enemySprite.move(0, 0.5f * enemyDir);
                if (enemySprite.getPosition().y < 0 || enemySprite.getPosition().y > 500)
                    enemyDir *= -1;
                enemyMoveClock.restart();
            }

            if (enemyFireClock.getElapsedTime().asMilliseconds() > 400)
            {
                enemyX[enemyIndex] = enemySprite.getPosition().x - 10;
                enemyY[enemyIndex] = enemySprite.getPosition().y + 25;
                enemyProjectiles[enemyIndex].setPosition(enemyX[enemyIndex], enemyY[enemyIndex]);
                enemyActive[enemyIndex] = true;
                enemyIndex = (enemyIndex + 1) % maxProjectiles;
                enemyFireClock.restart();
            }

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                {
                    playerX[i] += projSpeed;
                    playerProjectiles[i].setPosition(playerX[i], playerY[i]);
                    if (playerX[i] > 1018)
                        playerActive[i] = false;
                }
                if (enemyActive[i])
                {
                    enemyX[i] -= projSpeed;
                    enemyProjectiles[i].setPosition(enemyX[i], enemyY[i]);
                    if (enemyX[i] < 0)
                        enemyActive[i] = false;
                }
            }

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i] && playerProjectiles[i].getGlobalBounds().intersects(enemySprite.getGlobalBounds()))
                {
                    enemyhealth -= (10 + g.getattack() * 0.5);
                    playerActive[i] = false;
                }
                if (enemyActive[i] && enemyProjectiles[i].getGlobalBounds().intersects(playerSprite.getGlobalBounds()))
                {
                    g.sethealth(g.gethealth() - (100 - (g.getdef() * 0.5)));
                    enemyActive[i] = false;
                }
            }

            if (playerSprite.getGlobalBounds().intersects(potionBounds))
            {
                int boostType = rand() % 3;
                if (boostType == 0)
                    g.setattack(g.getattack() + 0.25);
                else if (boostType == 1)
                    g.setdef(g.getdef() + 0.25);
                else
                    g.setsped(g.getsped() + 0.25);
            }

            if (enemyhealth <= 0)
            {
                p.setcoins(p.getcoins() + 10);
                Texture winTex;
                winTex.loadFromFile("win.png");
                Sprite winSprite(winTex);
                window.clear();
                window.draw(winSprite);
                window.display();
                sleep(seconds(3));
                window.close();
                return;
            }

            if (g.gethealth() <= 0)
            {
                Texture loseTex;
                loseTex.loadFromFile("lose.png");
                Sprite loseSprite(loseTex);
                window.clear();
                window.draw(loseSprite);
                window.display();
                sleep(seconds(3));
                g.sethealth(og);
                window.close();
                return;
            }

            window.clear();
            window.draw(backgroundSprite);
            window.draw(playerSprite);
            window.draw(enemySprite);

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                    window.draw(playerProjectiles[i]);
                if (enemyActive[i])
                    window.draw(enemyProjectiles[i]);
            }

            window.display();
        }
    }

    void unicornbattle(unicorn u, player &p)
    {
        Texture playerProjectileTexture;
        playerProjectileTexture.loadFromFile("fireball.png");

        Texture enemyProjectileTexture;
        enemyProjectileTexture.loadFromFile("efireball.png");

        srand(time(0));
        int num = rand() % 4;
        int enemyhealth = 2000;
        int og = u.gethealth();
        RenderWindow window(VideoMode(1018, 573), "BATTLE ARENA");
        RectangleShape obstacle(Vector2f(101.f, 229.f));
        obstacle.setPosition(507.f, 400.f);
        Texture bg;
        bg.loadFromFile("battle1.png");
        Sprite backgroundSprite(bg);

        Texture playerTexture;
        playerTexture.loadFromFile("uni.png");
        Sprite playerSprite(playerTexture);
        playerSprite.setScale(0.5f, 0.5f);
        playerSprite.setPosition(100, 100);

        Texture enemyTexture;
        if (num == 0)
            enemyTexture.loadFromFile("dra.png");
        else if (num == 1)
            enemyTexture.loadFromFile("pho.png");
        else if (num == 2)
            enemyTexture.loadFromFile("uni.png");
        else
            enemyTexture.loadFromFile("g.png");

        Sprite enemySprite(enemyTexture);
        enemySprite.setScale(0.5f, 0.5f);
        enemySprite.setPosition(800, 100);

        float unicornspeed = u.getsped();
        float speed = 0.01f * unicornspeed;
        float projSpeed = 1.5f;

        const int maxProjectiles = 100;
        Sprite playerProjectiles[maxProjectiles];
        Sprite enemyProjectiles[maxProjectiles];
        bool playerActive[maxProjectiles] = {};
        bool enemyActive[maxProjectiles] = {};
        float playerX[maxProjectiles], playerY[maxProjectiles];
        float enemyX[maxProjectiles], enemyY[maxProjectiles];

        // Initialize the projectiles
        for (int i = 0; i < maxProjectiles; i++)
        {
            playerProjectiles[i].setTexture(playerProjectileTexture);
            playerProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
            enemyProjectiles[i].setTexture(enemyProjectileTexture);
            enemyProjectiles[i].setScale(0.1f, 0.1f); // Adjust as needed
        }

        int playerIndex = 0;
        int enemyIndex = 0;

        Clock fireClock;
        Clock enemyFireClock;
        Clock enemyMoveClock;

        float enemyDir = 1.0f;
        FloatRect potionBounds(507.f, 150.f, 50.f, 50.f);

        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {
                if (event.type == Event::Closed)
                {
                    window.close();
                }
            }

            FloatRect obstacleBounds = obstacle.getGlobalBounds();
            FloatRect currentBounds = playerSprite.getGlobalBounds();

            if (Keyboard::isKeyPressed(Keyboard::Up))
            {
                FloatRect next = currentBounds;
                next.top -= speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(0, -speed);
                }
            }
            if (Keyboard::isKeyPressed(Keyboard::Down))
            {
                FloatRect next = currentBounds;
                next.top += speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(0, speed);
                }
            }
            if (Keyboard::isKeyPressed(Keyboard::Left))
            {
                FloatRect next = currentBounds;
                next.left -= speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(-speed, 0);
                }
            }
            if (Keyboard::isKeyPressed(Keyboard::Right))
            {
                FloatRect next = currentBounds;
                next.left += speed;
                if (!next.intersects(obstacleBounds))
                {
                    playerSprite.move(speed, 0);
                }
            }

            if (Keyboard::isKeyPressed(Keyboard::Space) && fireClock.getElapsedTime().asMilliseconds() > 200)
            {
                playerX[playerIndex] = playerSprite.getPosition().x + 50;
                playerY[playerIndex] = playerSprite.getPosition().y + 25;
                playerProjectiles[playerIndex].setPosition(playerX[playerIndex], playerY[playerIndex]);
                playerActive[playerIndex] = true;
                playerIndex = (playerIndex + 1) % maxProjectiles;
                fireClock.restart();
            }

            if (Keyboard::isKeyPressed(Keyboard::Y))
            {
                u.ability1();
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                u.ability2();
            }
            if (Keyboard::isKeyPressed(Keyboard::M) && p.getnoofmana() > 0)
            {
                u.sethealth(u.gethealth() + p.getnoofmana());
                p.setnoofmana(p.getnoofmana() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::H) && p.getnoofheals() > 0)
            {
                u.sethealth(u.gethealth() + p.getnoofheals());
                p.setnoofheals(p.getnoofheals() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::S) && p.getnoofshields() > 0)
            {
                u.setdef(u.getdef() + p.getnoofshields());
                p.setnoofshields(p.getnoofshields() - 1);
            }
            if (Keyboard::isKeyPressed(Keyboard::B) && p.getnoofbuffs() > 0)
            {
                u.setattack(u.getattack() + p.getnoofbuffs());
                p.setnoofbuffs(p.getnoofbuffs() - 1);
            }
            if (enemyMoveClock.getElapsedTime().asMilliseconds() > 10)
            {
                enemySprite.move(0, 0.5f * enemyDir);
                if (enemySprite.getPosition().y < 0 || enemySprite.getPosition().y > 500)
                {
                    enemyDir *= -1;
                }
                enemyMoveClock.restart();
            }

            if (enemyFireClock.getElapsedTime().asMilliseconds() > 400)
            {
                enemyX[enemyIndex] = enemySprite.getPosition().x - 10;
                enemyY[enemyIndex] = enemySprite.getPosition().y + 25;
                enemyProjectiles[enemyIndex].setPosition(enemyX[enemyIndex], enemyY[enemyIndex]);
                enemyActive[enemyIndex] = true;
                enemyIndex = (enemyIndex + 1) % maxProjectiles;
                enemyFireClock.restart();
            }

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                {
                    playerX[i] += projSpeed;
                    playerProjectiles[i].setPosition(playerX[i], playerY[i]);
                    if (playerX[i] > 1018)
                        playerActive[i] = false;
                }
                if (enemyActive[i])
                {
                    enemyX[i] -= projSpeed;
                    enemyProjectiles[i].setPosition(enemyX[i], enemyY[i]);
                    if (enemyX[i] < 0)
                        enemyActive[i] = false;
                }
            }

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i] && playerProjectiles[i].getGlobalBounds().intersects(enemySprite.getGlobalBounds()))
                {
                    enemyhealth -= (10 + u.getattack() * 0.5);
                    playerActive[i] = false;
                }
                if (enemyActive[i] && enemyProjectiles[i].getGlobalBounds().intersects(playerSprite.getGlobalBounds()))
                {
                    u.sethealth(u.gethealth() - (100 - (u.getdef() * 0.5)));
                    enemyActive[i] = false;
                }
            }

            if (playerSprite.getGlobalBounds().intersects(potionBounds))
            {
                int boostType = rand() % 3;
                if (boostType == 0)
                    u.setattack(u.getattack() + 0.25);
                else if (boostType == 1)
                    u.setdef(u.getdef() + 0.25);
                else
                    u.setsped(u.getsped() + 0.25);
            }

            if (enemyhealth <= 0)
            {
                p.setcoins(p.getcoins() + 10);
                Texture winTex;
                winTex.loadFromFile("win.png");
                Sprite winSprite(winTex);
                window.clear();
                window.draw(winSprite);
                window.display();
                sleep(seconds(3));
                window.close();
                return;
            }

            if (u.gethealth() <= 0)
            {
                Texture loseTex;
                loseTex.loadFromFile("lose.png");
                Sprite loseSprite(loseTex);
                window.clear();
                window.draw(loseSprite);
                window.display();
                sleep(seconds(3));
                u.sethealth(og);
                window.close();
                return;
            }

            window.clear();
            window.draw(backgroundSprite);
            window.draw(playerSprite);
            window.draw(enemySprite);

            for (int i = 0; i < maxProjectiles; i++)
            {
                if (playerActive[i])
                    window.draw(playerProjectiles[i]);
                if (enemyActive[i])
                    window.draw(enemyProjectiles[i]);
            }

            window.display();
        }
    }
    void fighterselect(player &p)
    {
        RenderWindow window(VideoMode(1015, 573), "SELECT YOUR FIGTHER");

        Texture battlemenu;
        Sprite bg;
        if (!battlemenu.loadFromFile("fighterselect.png"))
        {
            cout << "eror";
        }
        bg.setTexture(battlemenu);
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {

                if (event.type == Event::Closed)
                    window.close();
            }
            if (Keyboard::isKeyPressed(Keyboard::G))
            {
                griffinbattle(p.getgriffin(), p);
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                unicornbattle(p.getunicorn(), p);
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                dragonbattle(p.getdragon(), p);
            }
            if (Keyboard::isKeyPressed(Keyboard::P))
            {
                phoenixbattle(p.getphoenix(), p);
            }
            window.clear();
            window.draw(bg);
            window.display();
        }
    }
};
// arena2v2 class inherits from arena1v1
class arena2v2 : public arena1v1
{
public:
// 2 v 2 battles have 2 pets battling one by one 
    void fighterselect(player &p,int a=-1,int b=-1)
    {
        RenderWindow window(VideoMode(1015, 573), "SELECT YOUR FIGTHER");

        Texture battlemenu;
        Sprite bg;
        if (!battlemenu.loadFromFile("fighterselect.png"))
        {
            cout << "eror";
        }
        bg.setTexture(battlemenu);
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {

                if (event.type == Event::Closed)
                    window.close();
            }
            if (Keyboard::isKeyPressed(Keyboard::G))
            {
                if(a>-1)
                {
                    if(a==0)
                    { // fighter seletion for 2 v 2 battles 
                        griffinbattle(p.getgriffin(), p);
                        griffinbattle(p.getgriffin(), p);
                    }
                    if(a==1)
                    {
                        griffinbattle(p.getgriffin(), p);
                        unicornbattle(p.getunicorn(), p);
                    }
                    if(a==2)
                    {
                        griffinbattle(p.getgriffin(), p);
                        dragonbattle(p.getdragon(), p);
                    }
                    if(a==3)
                    {
                        griffinbattle(p.getgriffin(), p);
                        phoenixbattle(p.getphoenix(), p);
                    }
                }
                else
                {
                    fighterselect(p,0,-1);
                }
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                if(a>-1)
                {
                    if(a==0)
                    {
                        unicornbattle(p.getunicorn(), p);
                        griffinbattle(p.getgriffin(), p);

                    }
                    if(a==1)
                    {
                        unicornbattle(p.getunicorn(), p);
                        unicornbattle(p.getunicorn(), p);
                    }
                    if(a==2)
                    {
                        unicornbattle(p.getunicorn(), p);
                        dragonbattle(p.getdragon(), p);
                    }
                    if(a==3)
                    {   
                        unicornbattle(p.getunicorn(), p);
                        phoenixbattle(p.getphoenix(), p);
                    }
                }
                else
                {
                    fighterselect(p,1,-1);
                }
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                if(a>-1)
                {
                    if(a==0)
                    {
                        dragonbattle(p.getdragon(), p);
                        griffinbattle(p.getgriffin(), p);

                    }
                    if(a==1)
                    {
                        dragonbattle(p.getdragon(), p);
                        unicornbattle(p.getunicorn(), p);
                    }
                    if(a==2)
                    {   
                        dragonbattle(p.getdragon(), p);
                        dragonbattle(p.getdragon(), p);
                    }
                    if(a==3)
                    {   
                        dragonbattle(p.getdragon(), p);
                        phoenixbattle(p.getphoenix(), p);
                    }
                }
                else
                {
                    fighterselect(p,2,-1);
                }
            }
            if (Keyboard::isKeyPressed(Keyboard::P))
            {
                if(a>-1)
                {
                    if(a==0)
                    {
                        phoenixbattle(p.getphoenix(), p);
                        griffinbattle(p.getgriffin(), p);

                    }
                    if(a==1)
                    {
                        phoenixbattle(p.getphoenix(), p);
                        unicornbattle(p.getunicorn(), p);
                    }
                    if(a==2)
                    {   
                        phoenixbattle(p.getphoenix(), p);
                        dragonbattle(p.getdragon(), p);
                    }
                    if(a==3)
                    {   
                        phoenixbattle(p.getphoenix(), p);
                        phoenixbattle(p.getphoenix(), p);
                    }
                }
                else
                {
                    fighterselect(p,3,-1);
                }
            }
            window.clear();
            window.draw(bg);
            window.display();
        }
    }
};
// guild class
class guild
{
private:
    // all the guild members and roles
    string tank;
    string healer;
    string damagedealer;
    string flyer;

public:
    string gettank()
    {
        return tank;
    }
    string gethealer()
    {
        return healer;
    }
    string getdamagedealer()
    {
        return damagedealer;
    }
    string getflyer()
    {
        return flyer;
    }
    void settank(string t)
    {
        tank = t;
    }
    void sethealer(string h)
    {
        healer = h;
    }
    void setdamagedealer(string d)
    {
        damagedealer = d;
    }
    void setflyer(string f)
    {
        flyer = f;
    }
    void operator()(string a, string b, string c, string d)
    {
        tank = a;
        healer = b;
        damagedealer = c;
        flyer = d;
    }
};
// guildwars class inheriting from arena2v2
// first making guild and then selecting the roles and then battling
class guildwars : public arena2v2
{
    guild g;

public:
    void flyerd(player &p)
    {
        RenderWindow window(VideoMode(1018, 573), "Select flyer");
        Texture battle;
        Sprite bg;
        if (!battle.loadFromFile("flyer.png"))
        {
            cout << "eror";
        }
        bg.setTexture(battle);
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {

                if (event.type == Event::Closed)
                    window.close();
            }
            if (Keyboard::isKeyPressed(Keyboard::G))
            {
                g.setflyer("griffin");
                tankd(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                g.setflyer("unicorn");
                tankd(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                g.setflyer("dragon");
                tankd(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::P))
            {
                g.setflyer("phoenix");
                tankd(p);
            }
            window.clear();
            window.draw(bg);
            window.display();
        }
    }
    void tankd(player &p)
    {
        RenderWindow window(VideoMode(1018, 573), "Select tank");
        Texture battle;
        Sprite bg;
        if (!battle.loadFromFile("tank.png"))
        {
            cout << "eror";
        }
        bg.setTexture(battle);
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {

                if (event.type == Event::Closed)
                    window.close();
            }
            if (Keyboard::isKeyPressed(Keyboard::G))
            {
                g.settank("griffin");
                healerd(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                g.settank("unicorn");
                healerd(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                g.settank("dragon");
                healerd(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::P))
            {
                g.settank("phoenix");
                healerd(p);
            }
            window.clear();
            window.draw(bg);
            window.display();
        }
    }
    void healerd(player &p)
    {
        RenderWindow window(VideoMode(1018, 573), "Select healer");
        Texture battle;
        Sprite bg;
        if (!battle.loadFromFile("healer.png"))
        {
            cout << "eror";
        }
        bg.setTexture(battle);
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {

                if (event.type == Event::Closed)
                    window.close();
            }
            if (Keyboard::isKeyPressed(Keyboard::G))
            {
                g.sethealer("griffin");
                damaged(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                g.sethealer("unicorn");
                damaged(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                g.sethealer("dragon");
                damaged(p);
            }
            if (Keyboard::isKeyPressed(Keyboard::P))
            {
                g.sethealer("phoenix");
                damaged(p);
            }
            window.clear();
            window.draw(bg);
            window.display();
        }
    }
    void damaged(player &p)
    { // guild wars have all pets battling
        RenderWindow window(VideoMode(1018, 573), "Select damage dealer");
        Texture battle;
        Sprite bg;
        if (!battle.loadFromFile("damagedealer.png"))
        {
            cout << "eror";
        }
        bg.setTexture(battle);
        while (window.isOpen())
        {
            Event event;
            while (window.pollEvent(event))
            {

                if (event.type == Event::Closed)
                    window.close();
            }
            if (Keyboard::isKeyPressed(Keyboard::G))
            {
                g.setdamagedealer("griffin");
                dragonbattle(p.getdragon(),p);
                unicornbattle(p.getunicorn(),p);
                phoenixbattle(p.getphoenix(),p);
                griffinbattle(p.getgriffin(),p);

            }
            if (Keyboard::isKeyPressed(Keyboard::U))
            {
                g.setdamagedealer("unicorn");
                dragonbattle(p.getdragon(),p);
                unicornbattle(p.getunicorn(),p);
                phoenixbattle(p.getphoenix(),p);
                griffinbattle(p.getgriffin(),p);
            }
            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                g.setdamagedealer("dragon");
                dragonbattle(p.getdragon(),p);
                unicornbattle(p.getunicorn(),p);
                phoenixbattle(p.getphoenix(),p);
                griffinbattle(p.getgriffin(),p);
            }
            if (Keyboard::isKeyPressed(Keyboard::P))
            {
                g.setdamagedealer("phoenix");
                dragonbattle(p.getdragon(),p);
                unicornbattle(p.getunicorn(),p);
                phoenixbattle(p.getphoenix(),p);
                griffinbattle(p.getgriffin(),p);
            }
            window.clear();
            window.draw(bg);
            window.display();
        }
    }
};
void battlemenu(player &p)
{ // battle menu for 1v1 , 2v2 and guild wars
    RenderWindow window(VideoMode(1015, 573), "CHOSE YOUR BATTLE OR CROSS OUT TO EXIT ");
    arena1v1 *a = new arena1v1;
    arena2v2 *b = new arena2v2;
    guildwars *c = new guildwars;
    Texture battlemenu;
    Sprite bg;
    if (!battlemenu.loadFromFile("battlemenu.png"))
    {
        cout << "eror";
    }
    bg.setTexture(battlemenu);
    while (window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {

            if (event.type == Event::Closed)
                window.close();
        }
        if (Keyboard::isKeyPressed(Keyboard::Num8))
        {
            a->fighterselect(p);
        }
        if (Keyboard::isKeyPressed(Keyboard::Num9))
        {
            b->fighterselect(p);
        }
        if (Keyboard::isKeyPressed(Keyboard::Num0))
        {
            c->flyerd(p);
        }
        window.clear();
        window.draw(bg);
        window.display();
    }
    delete a;
    delete b;
    delete c;
}
// game function for main menu
int  game()
{
    player p;
    shop *sh = new shop; // dma for shop and training camp
    trainingcamp *tr = new trainingcamp;
    Music music;
    if (!music.openFromFile("bgmusic.ogg"))
    {
        return -1;
    }
    music.setLoop(true);
    music.setVolume(100.f);
    music.play();
    RenderWindow window(sf::VideoMode(1018, 573), "MAGICAL PETS KINGDOM");
    Texture bg1;
    bg1.loadFromFile("bg.png");
    Sprite backgroundSprite;
    backgroundSprite.setTexture(bg1);
    while (window.isOpen())
    {
        Event event;
        // options for battle , train , shop , save file or load save file
        if (Keyboard::isKeyPressed(Keyboard::Num1))
        {
            battlemenu(p);
        }
        if (Keyboard::isKeyPressed(Keyboard::Num2))
        {
            sh->buyitem(p);
        }
        if (Keyboard::isKeyPressed(Keyboard::Num3))
        {
            tr->trainpet(p);
        }
        if (Keyboard::isKeyPressed(Keyboard::L))
        {
            p.loadotherdata();
            p.loadData();
            p.loadpetdata();
        }
        if(Keyboard::isKeyPressed(Keyboard::S))
        {
            p.storeotherdata();
            p.storepetdata();
            p();
        }
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();
        }
        window.clear();
        window.draw(backgroundSprite);
        window.display();
    }
    delete sh;
    delete tr;   
    return 0;
}
int main()
{
    game();
    return 0;
}
